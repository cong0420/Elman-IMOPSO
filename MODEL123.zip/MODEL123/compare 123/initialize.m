
function chromo = initialize(pop)
    
   global NP f_num x_num  % ��Ҫ�õ��Ĳ���
  chromo = zeros(NP, x_num+f_num);
    
DIM1=12;%������
DIM2=8;
%%
%       for i=1:NP
%           
%               for ii=1:DIM1
%                   for jj=1:DIM9
%                       if(ii==1)
%                         chromo(i,jj) =pop(i).b(ii,jj);
%                       elseif(ii==2)
%                         chromo(i,jj+12) =pop(i).b(ii,jj);
%                         elseif(ii==3)
%                         chromo(i,jj+24) =pop(i).b(ii,jj);
%                         elseif(ii==4)
%                         chromo(i,jj+36) =pop(i).b(ii,jj);
%                         elseif(ii==5)
%                         chromo(i,jj+48) =pop(i).b(ii,jj);
%                       else
%                         chromo(i,jj+60) =pop(i).b(ii,jj);
%                       end
%                   end
%               end
%             chromo(i,x_num+1) =pop(i).Fit1;
%             chromo(i,x_num+2) =pop(i).Fit2;
%       end
    for i=1:NP
          
              for ii=1:DIM1
                  for jj=1:DIM2
                      if(ii==1)
                        chromo(i,jj) =pop(i).X(ii,jj);
                        elseif(ii==2)
                        chromo(i,jj+8) =pop(i).X(ii,jj);
                        elseif(ii==3)
                        chromo(i,jj+16) =pop(i).X(ii,jj);
                        elseif(ii==4)
                        chromo(i,jj+24) =pop(i).X(ii,jj);
                        elseif(ii==5)
                        chromo(i,jj+32) =pop(i).X(ii,jj);
                        elseif(ii==6)
                        chromo(i,jj+40) =pop(i).X(ii,jj);
                        elseif(ii==7)
                        chromo(i,jj+48) =pop(i).X(ii,jj);
                        elseif(ii==8)
                        chromo(i,jj+56) =pop(i).X(ii,jj);
                        elseif(ii==9)
                        chromo(i,jj+64) =pop(i).X(ii,jj);
                        elseif(ii==10)
                        chromo(i,jj+72) =pop(i).X(ii,jj);
                        elseif(ii==11)
                        chromo(i,jj+80) =pop(i).X(ii,jj);
                        else
                        chromo(i,jj+88) =pop(i).X(ii,jj);
                      end
                  end
              end
            chromo(i,x_num+1) =pop(i).Fit1;
            chromo(i,x_num+2) =pop(i).Fit2;
      end
end
