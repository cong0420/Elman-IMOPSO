function chromo = mutation2(chromo_cro)
global NP x_num f_num x_min x_max pm yita2
%% ������ʼ��
count=0;
DIM1=6;%������
DIM2=4;%�¼�����
DIM3= 11;%��Դ����
DIM4=3;%�豸��Դ��,ÿ�����׶�һ����Դ���ܹ��������׶�����
DIM5= 8;%������Դ��
DIM6= 2;%��Դ�ϵ�������
DIM7= 4;%������Դ��
DIM8=2;%��һ�׶ε�������
DIM9=6;%p.xת��Ϊb��w���ά��
DIM10= 2;%���׶ε�������
DIM11= 4;%���еĽ׶�֮�����������stnͼ��������ʼ���м�ͽ���������
%%
I=[1,2;3,4;5,6;1,0;2,0;1,3;2,4;3,5;4,6;5,0;6,0];%��Դ�ϵ���������
%Emax;��Դ���Ƶ�����
Emin=[0,0,0,0,0,0,0,0,0,0,0];%��Դ���Ƶ�����
resource_restore= [6,7,8,9];%�п�����Ƶ�������Դ
bmin=[5,5,5,5,5,5];%��������������
bmax=[150,150,150,150,150,150];%��������������
fix_task=[10,10,10,10,10,10];%����̶�������ʱ��
change_task=[1,1,1,1,1,1];%����䶯������ʱ��
stage_material=[2,2,2,2];%���׶εĲ�Ʒ����
stage_task=[2,2,2];%���׶ε���������
demand=[300,300,300,300,300,300];
Emax=[1,1,1,300,300,200,200,200,200,300,300];
 change=[1,1,1,1,1,1];
%change=[[0,1,0,0,0,0],[1,0,0,0,0,0],[0,0,0,1,0,0],[0,0,1,0,0,0],[0,0,0,0,0,1],[0,0,0,0,1,0]];
sum=0;
temp13=zeros(1,4);
temp35=zeros(1,4);
temp24=zeros(1,4);
temp46=zeros(1,4);
tempp13=zeros(1,4);
tempp35=zeros(1,4);
tempp24=zeros(1,4);
tempp46=zeros(1,4);
sum1=0;sum2=0;sum3=0;sum4=0;
%%%%1.����һ�������ṹ�壻
POP.X = zeros(DIM1,DIM2);
POP.XBest=zeros(DIM1,DIM2);
POP.FIT=zeros(2,1);
POP.Fit1=0;POP.Fit2=0;
POP.FitBest=zeros(2,1);
POP.bb= zeros(DIM1,DIM9);
POP.tts= zeros(DIM1,DIM9);
POP.temp=zeros(1,6);
POP.tempp=zeros(1,3);
pop = repmat(POP,1,NP);%%
zc1=[1,7,14,20,27,33];
zc2=[2,8,15,21,28,34];
zc3=[3,9,16,22,29,35];
zc4=[4,10,17,23,30,36];
%%

chromo = chromo_cro(:,1:x_num);  % ������ chromo_cro �����Ƕ����ˣ�������ֻ�õ� x_num ��

for j = 1:NP

         m=randperm(4,1);  
if(m==1)
    m1=randperm(6,2);
    temp=chromo(j,m1(1));
    chromo(j,m1(1))=chromo(j,m1(2));
    chromo(j,m1(2))=temp;
elseif(m==2)
    m1=randperm(12,2);
    temp=chromo(j,m1(1));
    chromo(j,m1(1))=chromo(j,m1(2));
    chromo(j,m1(2))=temp;
elseif(m==3)
    m1=randperm(12,2);
    temp=chromo(j,m1(1));
    chromo(j,m1(1))=chromo(j,m1(2));
    chromo(j,m1(2))=temp;
else
    m1=randperm(6,2);
    temp=chromo(j,m1(1));
    chromo(j,m1(1))=chromo(j,m1(2));
    chromo(j,m1(2))=temp;
end
    
    % ���峬���˾��޸���
    chromo(j,1:x_num) = min(chromo(j,1:x_num), x_max(1,:));
    chromo(j,1:x_num) = max(chromo(j,1:x_num), x_min(1,:));
end
    %%
    for i=1:NP
       
        for jj=1:x_num
            if(jj<=6)
                pop(i).bb(1,jj)=chromo(i,jj) ; 
            elseif(jj>6&&jj<=12)
                pop(i).bb(2,jj-6)=chromo(i,jj) ;
            elseif(jj>12&&jj<=18)
                pop(i).bb(3,jj-12)=chromo(i,jj) ;
            elseif(jj>18&&jj<=24)
                pop(i).bb(4,jj-18)=chromo(i,jj) ;
            elseif(jj>24&&jj<=30)
                pop(i).bb(5,jj-24)=chromo(i,jj) ;
            else
                pop(i).bb(6,jj-30)=chromo(i,jj) ;
            end
        end
        
    end
 %%
    for j=1:NP
         %�����м��������Ƶ���
            
            
  for a=1:DIM3
    for b=1:DIM9+1
        E(a,b)=0;%�м��Ʒ�ۼ���
    end
end
k=0;

for a=3:4
    
    b=1;
    %3,2;4,2
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=Emax(a+3))
        pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
        k=b+1;
    else
        E(a,b+1)=pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1);
        
        if(E(a,b+1)>=0)
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
            pop(j).bb(a-2,b+1)=0;
            k=b+2;
            q1=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q1;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q1;
        else
            k=b+1;
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2);
            pop(j).bb(a-2,b+1)=0;pop(j).bb(a-2,b+2)=0;
            k=b+3;
            q2=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q2;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q2;
        end    
    end
        b=3;
        E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);%3,3;4,3
        if(E(a,b)>=0&&E(a,b)<=200)
            E(a,b)=E(a,b);
            pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1);
        else
            if(E(a,b)<0)
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+pop(j).bb(a-2,b);
                pop(j).bb(a-2,b)=0;pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                tem1=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)-tem1;
                if(pop(j).bb(a-2,b)>=-tem1)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+tem1;
                else
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+tem1;
                end
                E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                E(a,b+1)=E(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);%3,4;4,4
                if(E(a,b+1)>=0&&E(a,b+1)<=200)
                    E(a,b+1)=E(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                elseif(E(a,b+1)<0)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
                    pop(j).bb(a-2,b+1)=0;
                    tem2=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-tem2;
                    pop(j).bb(a-2,b+1)=300-pop(j).bb(a-2,b)-pop(j).bb(a-2,b-1)-pop(j).bb(a-2,b-2);
                end
            end
            if(E(a,b)>200)
                temp=E(a,b)-200;
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+temp;
                pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-temp;
                E(a,b)=200;
            end
        end
        if (pop(j).bb(a-2,4)<0)
            pop(j).bb(a-2,3)=pop(j).bb(a-2,3)-pop(j).bb(a-2,4);
            pop(j).bb(a-2,4)=0;
        end
        if(pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1)>300)
            for n=4:-1:1
                if(pop(j).bb(a-2,n)~=0)
                    pop(j).bb(a-2,n)=pop(j).bb(a-2,n)-((pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1))-300);
                end
            end
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for a=5:6
    
    b=2;
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=Emax(a+3))
        pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
    else
        if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<0)
            w1=pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w1;
            pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w1;
        end
    end
    
    b=4;
    E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
    if(E(a,b)>=0&&E(a,b)<=200)
        pop(j).bb(a,b)=pop(j).bb(a,b);
    else
        if(E(a,b)<0)
            w2=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            pop(j).bb(a,b)=pop(j).bb(a,b)+w2;
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w2;
            E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            if(E(a,b)>200)
                temp=E(a,b)-200;
                pop(j).bb(a,b)=pop(j).bb(a-2,b)-temp;
                pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)+temp;
                E(a,b)=200;
            end
            E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            if(E(a,b+1)>=0&&E(a,b+1)<=200)
                pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
            else
                if(E(a,b+1)<0)
                    w3=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w3;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w3;
                    E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    if(E(a,b+1)>200)
                        temp=E(a,b)-200;
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+1)=200;
                    end
                   
                end
            end
                        E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
            if(E(a,b+2)>=0&&E(a,b+2)<=Emax(a+3))
                pop(j).bb(a,b+2)=pop(j).bb(a,b+2);
            else
                if(E(a,b+2)<0)
                    w4=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w4;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)+w4;
                    E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    if(E(a,b+2)>Emax(a+3))
                        temp=E(a,b)-Emax(a+3);
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+2)=Emax(a+3);
                    end
                   
                end
            end
        end
        
    end
    
    if(pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3)>300)
        for n=6:-1:3
            if(pop(j).bb(a,n)~=0)
                pop(j).bb(a,n)=pop(j).bb(a,n)-((pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3))-300);
            end
        end
    end
end
       
        % % % %             %2.calmodel
        
        pop(j).tts= zeros(DIM1,DIM9);
        for i=1:stage_task(1)
            pop(j).tts(i,1)=0;          %����ʼ����ĵ�һ���豸�ĸ�����ĵ�һ��������ֵΪ��
        end
        total_stage_task=stage_task(1);
        for is=2:DIM4
            
            for i=(total_stage_task+1):(total_stage_task+stage_task(is))
                
                for n=1:is
                    pop(j).tts(i,n)=0;
                end
            end
            total_stage_task=total_stage_task+stage_task(is);
        end                                  %�������Ǹ���ֵΪ��
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        total_stage_task=0;
        
        pop(j).tts(1,1)=pop(j).bb(1,1)*change_task(1)+fix_task(1);
        pop(j).tts(2,1)=(pop(j).tts(1,1)+(pop(j).bb(2,1)*change_task(1)+fix_task(1)));
        for i=(total_stage_task+1):(DIM1)
            for n=1:DIM9-DIM4+3
                immediate_t1=0;immediate_t2=0;immediate_t3=0;immediate_t4=0;
                if(i-DIM6<=0)
                    if(n==2)
                        if(i==1)
                            %1,2
                            immediate_t1=(pop(j).tts(i+1,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                            
                        elseif(i==2)
                            %2,2
                            immediate_t1=(pop(j).tts(i-1,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                            %1,3
                            immediate_t1=pop(j).tts(i,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                            immediate_t2=pop(j).tts(i-1,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                            pop(j).tts(i-1,n+1)=maxx(immediate_t1,immediate_t2);
                            
                        end
                        
                    end
                    
                end
                
                if(i-DIM6>0)
                    %3,2;3,3;4,2;4,3
                    if(n+1<=3)
                        if(i==3)
                            immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n+1)=maxx(immediate_t1,immediate_t2);
                        elseif(i==4)
                            immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i-1,n+1)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n+1)=maxx((maxx(immediate_t1,immediate_t2)),pop(j).tts(i-2,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                        end
                    end
                    %     5,3;5,4;6,3;6,4
                    if(n+2<=4)
                        if(i==5)
                            immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n+2)=maxx(immediate_t1,immediate_t2);
                        elseif(i==6)
                            immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                            immediate_t2=(pop(j).tts(i-1,n+2)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                            pop(j).tts(i,n+2)=maxx((maxx(immediate_t1,immediate_t2)),(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i))));
                        end
                    end
                    
                end
                total_stage_task=total_stage_task+stage_task(is);
            end
        end
        
        
        pop(j).tts(2,3)=maxx(pop(j).tts(1,3)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)),pop(j).tts(2,2)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)));
        pop(j).tts(1,4)=maxx(pop(j).tts(2,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)),pop(j).tts(1,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)));
        pop(j).tts(2,4)=maxx(pop(j).tts(1,4)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)),pop(j).tts(2,3)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)));
        
        pop(j).tts(3,4)=maxx(pop(j).tts(1,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)),pop(j).tts(3,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)));
        pop(j).tts(4,4)=maxx(maxx(pop(j).tts(2,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)),pop(j).tts(3,4)+(pop(j).bb(4,4)*change_task(4)+fix_task(4))),pop(j).tts(4,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)));
        pop(j).tts(3,5)=maxx(pop(j).tts(1,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)),pop(j).tts(3,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)));
        pop(j).tts(4,5)=maxx(maxx(pop(j).tts(2,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)),pop(j).tts(3,5)+(pop(j).bb(4,5)*change_task(5)+fix_task(5))),pop(j).tts(4,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)));
        
        pop(j).tts(5,5)=maxx(pop(j).tts(3,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)),pop(j).tts(5,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)));
        pop(j).tts(6,5)=maxx(maxx(pop(j).tts(4,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)),pop(j).tts(5,5)+(pop(j).bb(6,5)*change_task(5)+fix_task(5))),pop(j).tts(6,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)));
        pop(j).tts(5,6)=maxx(pop(j).tts(3,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)),pop(j).tts(5,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)));
        pop(j).tts(6,6)=maxx(maxx(pop(j).tts(4,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)),pop(j).tts(5,6)+(pop(j).bb(6,6)*change_task(6)+fix_task(6))),pop(j).tts(6,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)));
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Լ����������
        
pop(j).Fit1=pop(j).tts(DIM1,DIM9)-pop(j).tts(2,1);
fff=pop(j).tts(DIM1-1,DIM9)-pop(j).tts(1,1);

if(pop(j).Fit1>fff&&fff~=0)
    pop(j).Fit1=fff;
end

%  pop(j).Fit2=pop(j).tts(DIM1,DIM9);
 
 %            pop(j).Fit2=pop(j).bb(4,4)-pop(j).bb(4,3)+pop(j).bb(5,5)-pop(j).X(5,4)+pop(j).bb(6,5)-pop(j).bb(6,4);

temp13(1)=pop(j).bb(1,1)-pop(j).bb(3,2);
 temp35(1)=pop(j).bb(3,2)-pop(j).bb(5,3);
 for i=1:3
     if(temp13(i)>=0)
         temp13(i+1)=temp13(i)+pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     else
         temp13(i+1)=pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     end
     if(temp35(i)>=0)
         temp35(i+1)=temp35(i)+pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     else
         temp35(i+1)=pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     end
 end
 temp24(1)=pop(j).bb(2,1)-pop(j).bb(4,2);
 temp46(1)=pop(j).bb(4,2)-pop(j).bb(6,3);
 for i=1:3
     if(temp24(i)>=0)
         temp24(i+1)=temp24(i)+pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     else
         temp24(i+1)=pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     end
     if(temp46(i)>=0)
         temp46(i+1)=temp46(i)+pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     else
         temp46(i+1)=pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     end
 end

                
tempp13(1)=(pop(j).tts(3,2)-pop(j).tts(1,1)-fix(pop(j).bb(3,2)*change_task(2)-fix_task(2)));
tempp35(1)=(pop(j).tts(5,3)-pop(j).tts(3,2)-fix(pop(j).bb(5,3)*change_task(3)-fix_task(3)));
for i=1:3
     if(tempp13(i)>=0)
         tempp13(i+1)=(pop(j).tts(3,i+2)-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1))-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp13(i+1)=(pop(j).tts(3,i+2))-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1)-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp35(i)>=0)
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 tempp24(1)=(pop(j).tts(4,2)-maxx(pop(j).tts(2,1),pop(j).tts(3,2))-fix(pop(j).bb(4,2)*change_task(2)-fix_task(2)));
 tempp46(1)=(pop(j).tts(6,3)-maxx(pop(j).tts(4,2),pop(j).tts(5,3))-fix(pop(j).bb(6,3)*change_task(3)-fix_task(3)));
 for i=1:3
     if(tempp24(i)>=0)
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp46(i)>=0)
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 for i=1:4
     sum1=sum1+2*temp13(i)*tempp13(i);
     sum2=sum2+2*temp35(i)*tempp35(i);
     sum3=sum3+2*temp24(i)*tempp24(i);
     sum4=sum4+2*temp46(i)*tempp46(i);
 end

     sum=sum1+sum2+sum3+sum4;
 pop(j).Fit2=sum;
    end
    %%
      for i=1:NP
          
              for ii=1:DIM1
                  for jj=1:DIM2
                      if(ii==1)
                        chromo(i,jj) =pop(i).bb(ii,jj);
                      elseif(ii==2)
                        chromo(i,jj+6) =pop(i).bb(ii,jj);
                        elseif(ii==3)
                        chromo(i,jj+12) =pop(i).bb(ii,jj);
                        elseif(ii==4)
                        chromo(i,jj+18) =pop(i).bb(ii,jj);
                        elseif(ii==5)
                        chromo(i,jj+24) =pop(i).bb(ii,jj);
                      else
                        chromo(i,jj+30) =pop(i).bb(ii,jj);
                      end
                  end
              end
            chromo(i,x_num+1) =pop(i).Fit1;
            chromo(i,x_num+2) =pop(i).Fit2;
      end
end


