function z=yueshu(pop)
global NP
%% ������ʼ��
count=0;
DIM1=12;%������
DIM2=8;%�¼�����
DIM3=19;%��Դ����
DIM4=3;%�豸��Դ��,ÿ�����׶�һ����Դ���ܹ��������׶�����
DIM5= 16;%������Դ��
DIM6= 4;%��Դ�ϵ�������
DIM7= 8;%������Դ��
DIM8=4;%��һ�׶ε�������
DIM9=36;%p.xת��Ϊb��w���ά��
DIM10=4;%���׶ε�������
DIM11=4;%���еĽ׶�֮�����������stnͼ��������ʼ���м�ͽ���������
%%
I=[1,2,3,4;5,6,7,8;9,10,11,12;1,0,0,0;2,0,0,0;3,0,0,0;4,0,0,0;1,5,0,0;2,6,0,0;3,7,0,0;4,8,0,0;5,9,0,0;6,10,0,0;7,11,0,0;8,12,0,0;9,0,0,0;10,0,0,0;11,0,0,0;12,0,0,0];%��Դ�ϵ���������
beta=[1.0,1.0,1.0,1.0,0.9,0.9,0.9,0.9,0.8,0.8,0.8,0.8];
%Emax;��Դ���Ƶ�����
Emin=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];%��Դ���Ƶ�����
resource_restore= [6,7,8,9];%�п�����Ƶ�������Դ
bmin=[5,5,5,5,5,5,5,5,5,5,5,5];%��������������
% bmax=[12.9,12.9,12.9,12.9,17.8,17.8,17.8,17.8,21.5,21.5,21.5,21.5];%��������������
bmax=[14.74,14.74,14.74,14.74,18.05,18.05,18.05,18.05,21.70,21.70,21.70,21.70];%��������������
fix_task=[4,3,5,4.5,3,2.5,2.6,2.8,6,5.5,6.4,5];%����̶�������ʱ��
change_task=[0.1,0.15,0.12,0.13,0.1,0.1,0.21,0.15,0.1,0.11,0.09,0.12];%����䶯������ʱ��
stage_material=[4,4,4,4];%���׶εĲ�Ʒ����
stage_task=[4,4,4];%���׶ε���������
  %demand=[19.44,22.22,20.83,16.67,19.44,22.22,20.83,16.67,17.49,19.99,18.74,15];
 demand=[22.24,20.85,23.64,20.85,22.24,20.85,23.64,20.85,20,18.75,21.25,18.75];
 Emax=[1,1,1,300,300,300,300,16,17,16,16,20,22,21,23,300,300,300,300];
% Emax=[1,1,1,300,300,300,300,23,22.84,22.23,21.06,24.5,25.75,25,26.25,300,300,300,300];
change=[[0,0,0,1,0,0,0,0,0,0,0,0],[0,0,1,0,0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,1,0,0,0,0],[0,0,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,1,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,1,0,0,0],[0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0],[0,0,0,0,0,0,0,0,0,0,0,1]];

for j=1:numel(pop)

%���豸��ĳ����ѡ��һ������Ϊ��

%��ͬ�豸����ͬһ��ֻ��һ����������

count=zeros(DIM1);
ran=zeros(DIM6);
sort=zeros(DIM6);
for r=1:DIM4
    for n=1:DIM2
        for i=1:DIM6
            ran(i)=rand(1);
            if(ran(i)<0)
                ran(i)=-ran(i);
            elseif(ran(i)==0)
                ran(i)=0.5;
            end
        end
        
        for  j1=1:DIM6
            sort(j1)=I(r,j1);
        end
        
        for ii=1:DIM6%��ran��ֵ�����������Ѿ�ѡ��DIM2/DIM6�ģ�������ѡ
            ic=I(r,ii);
            
            batch_num_i=ceil(demand(ic)/bmax(ic));
            if(demand(ic)/bmax(ic)>=batch_num_i)
               batch_num_i=batch_num_i+1;
            end
            if(count(ic)>=batch_num_i)
                ran(ii)=0;
            end
        end
       
        total_ran=0;
        for i=1:DIM6
            total_ran=total_ran+ran(i);
        end
        return_i=1;
        if(total_ran==0)
            return_i=0;
        end
        if(return_i~=0)
           
            for iii=1:DIM6-1
                for jjj=iii+1:DIM6
                    if(ran(iii)<ran(jjj))
                        
                        tmp=ran(jjj);
                        ran(jjj)=ran(iii);
                        ran(iii)=tmp;
                        tmpp=sort(jjj);
                        sort(jjj)=sort(iii);
                        sort(iii)=tmpp;
                    end
                end
            end
            
            return_i=sort(1);
         end
        
  
        ii=return_i;%���豸r��Ӧ�ÿ��Բ�Ϊ���������
        if(ii>=1)
             count(ii)=count(ii)+1;%����ѡ�в�Ϊ����������ܵ����������ϼ�һ.
            for  ie=1:DIM6
                ir=I(r,ie);
                
                if(ir~=ii)%���豸�ϵ�ĳ�����������豸��ĳ���ϵ������������ʱ�����豸�ϲ���һ������ʱ
                    pop(j).X(ir,n)=0;%�õ��ϵ�����Ϊ0
                end
            end
            
        else
            for  ie=1:DIM6
                ir=I(r,ie);
                pop(j).X(ir,n)=0;
            end
            
        end
    end
end

%     for ii=1:DIM1
%         [row,col]=find(pop(j).X(ii,:)~=0);
%         [row1,col1]=find(pop(j).X(ii,:)==0);
% %         if(size(row,2)>ceil(demand(ii)/bmax(ii)))
% %             kk=randperm(size(col,2),1);
% %             pop(j).X(ii,col(kk))=0;
%        if(size(row,2)<ceil(demand(ii)/bmax(ii)))
%             
%             kk=randperm(size(col1,2),1);
%             if(mod(ii,2)==0)
%                 while(pop(j).X(ii-1,col1(kk))~=0)
%                     kk=randperm(size(col1,2),1);
%                 end
%             else
%                 while(pop(j).X(ii+1,col1(kk))~=0)
%                     kk=randperm(size(col1,2),1);
%                 end
%             end
%             pop(j).X(ii,col1(kk))=bmax(ii);
%         end
%     end
   

    %2.XIUFU2������������
    D=zeros(1,DIM1);
    for i2=1:DIM1
        for n2=1:DIM2
            
            D(i2)=D(i2)+pop(j).X(i2,n2);
        end
        if(D(i2)>demand(i2))%�������������󣬴Ӻ���ǰ����
            
            for j2=(DIM2):-1:1
                D(i2)=D(i2)-pop(j).X(i2,j2);
                if(D(i2)>demand(i2))
                    pop(j).X(i2,j2)=0;
                else
                    pop(j).X(i2,j2)=demand(i2)-D(i2);
                    D(i2)=demand(i2);
                end
                if(D(i2)==demand(i2))
                    break;
                end
            end
        end
        if(D(i2)<demand(i2))%�������������󣬴Ӻ���ǰ����
            for j2=(DIM2):-1:1
                if(pop(j).X(i2,j2)~=0)
                    D(i2)=D(i2)+bmax(i2)-pop(j).X(i2,j2);
                    if(D(i2)<=demand(i2))
                        pop(j).X(i2,j2)=bmax(i2);
                    else
                        pop(j).X(i2,j2)=bmax(i2)-(D(i2)-demand(i2));
                        D(i2)=demand(i2);
                    end
                end
                if(D(i2)==demand(i2))
                    break;
                end
            end
        end
      
    end

     %p.xת��Ϊp.b
     for r=1:DIM4
         for i=1:DIM6
             im=I(r,i);
             for n=1:r
                 pop(j).b(im,n)=0;%ǰ����0
             end
             for n=r+1:r+DIM2
                 pop(j).b(im,n)=pop(j).X(im,n-r);%ת��p.b
             end
             for n=r+DIM2+1:DIM9
                 pop(j).b(im,n)=0;%������0
             end
         end
     end

    %Ư�ƣ������ɿ��еĹ�Ӧ���Ͻṹ
    E=zeros(DIM3,DIM9);

    total_stage=DIM4+stage_material(1);%�豸����+��Ʒ��Դ
    for sm=2:DIM11-1
        
        for r=(total_stage+1):(total_stage+stage_material(sm))
            E(r,sm-1)=0;
        end
        total_stage=total_stage+stage_material(sm);
    end            %�����������ϵ��м��Ʒ�ۼ�������0����ʼ����ԴΪ0��
    

for n=1:DIM9-DIM4+1
        total_stage=DIM4+stage_material(1);
  
        for sm=2:DIM11-1
            for r=total_stage+1:total_stage+stage_material(sm)
                i1=I(r,1);
                i2=I(r,2);
                E(r,n+1+sm-2)=E(r,n+sm-2)+pop(j).b(i1,n+sm-2)*beta(i1)-pop(j).b(i2,n+1+sm-2);
                if(E(r,n+1+sm-2)<-0.00001)
                    rs=sm;
                    nm=0;%�ƶ��ĵ���
                    for n1=(n+sm):(DIM9-DIM4+sm)  %�ҵ�����Ư�Ƶ��ĵ�������
                        nm=nm+1;
                        sum_rs=0;
                        for i=1:DIM6
                            i3=I(rs,i);
                            sum_rs=sum_rs+pop(j).b(i3,n1);
                        end
                        if(sum_rs==0)
                            break;
                        end
                    end 
                        if (sum_rs~=0)
                            E(r,n+1+sm-2)=E(r,n+1+sm-2)+pop(j).b(i2,n+1+sm-2);
                             pop(j).b(i2,n+1+sm-2)=0;
                        else
                            pop(j).b(i2,n+1+sm-2+nm)=pop(j).b(i2,n+1+sm-2);
                            E(r,n+1+sm-2)=E(r,n+1+sm-2)+pop(j).b(i2,n+1+sm-2);      
                            pop(j).b(i2,n+1+sm-2)=0;
                        end
                end
            end
             total_stage=total_stage+stage_material(sm);
        end

             total_stage= DIM3-stage_material(DIM11);
        
        for sm=DIM11-1:-1:2
            
            for r=total_stage-stage_material(sm)+1:total_stage
                i1=I(r,1);
                i2=I(r,2);
                E(r,n+1+sm-2)=E(r,n+sm-2)+pop(j).b(i1,n+sm-2)*beta(i1)-pop(j).b(i2,n+1+sm-2);
                if(E(r,n+1+sm-2)-Emax(r)>0.00001)
                    rs=sm-1;
                    nm=1;%�ƶ��ĵ���
                    for n1=n+sm-2+1:DIM9-DIM4+sm%�ҵ�����Ư�Ƶ��ĵ�������
                        nm=nm+1;
                        sum_rs=0;
                        for i=1:DIM6
                            i3=I(rs,i);
                            sum_rs=sum_rs+pop(j).b(i3,n1);
                        end
                        if(sum_rs==0)
                            break;
                        end
                         
                    end

                    if(sum_rs~=0)
                        E(r,n+1+sm-2)= E(r,n+1+sm-2)-pop(j).b(i1,n+1+sm-2-1)*beta(i1);
                         pop(j).b(i1,n+1+sm-2-1)=0;                       
                    else
                        pop(j).b(i1,n+1+sm-2-1+nm)=pop(j).b(i1,n+1+sm-2-1);
                        E(r,n+1+sm-2)=E(r,n+1+sm-2)-pop(j).b(i1,n+1+sm-2-1)*beta(i1);
                        pop(j).b(i1,n+1+sm-2-1)=0;
                    end 
                    
                end
            end
            total_stage=total_stage-stage_material(sm);
        end
        
end 
qq=1;
while(qq<=5)
for ii=1:DIM9
    for mm=DIM8-1:-1:1
        for nn=DIM8:-1:mm+1
            if pop(j).b(mm,ii)~=0&&pop(j).b(nn,ii)~=0
                if pop(j).b(mm,ii-1)==0
                    pop(j).b(mm,ii-1)=pop(j).b(mm,ii);
                    pop(j).b(mm,ii)=0;
                else
                    pop(j).b(mm,ii-2)=pop(j).b(mm,ii-1);
                    pop(j).b(mm,ii-1)=pop(j).b(mm,ii);
                    pop(j).b(mm,ii)=0;
                end
                if pop(j).b(mm+4,ii)==0
                    pop(j).b(mm+4,ii)=pop(j).b(mm+4,ii+1);
                    pop(j).b(mm+4,ii+1)=0;
                end
                
            end
        end
    end
    for mm=DIM8*2:-1:5
        for nn=DIM8*2:-1:mm+1
            if pop(j).b(mm,ii)~=0&&pop(j).b(nn,ii)~=0
                if pop(j).b(mm,ii-1)==0
                    pop(j).b(mm,ii-1)=pop(j).b(mm,ii);
                    pop(j).b(mm,ii)=0;
                else
                    pop(j).b(mm,ii-2)=pop(j).b(mm,ii-1);
                    pop(j).b(mm,ii-1)=pop(j).b(mm,ii);
                    pop(j).b(mm,ii)=0;
                end
                if pop(j).b(mm+4,ii)==0
                    pop(j).b(mm+4,ii)=pop(j).b(mm+4,ii+1);
                    pop(j).b(mm+4,ii+1)=0;
                end
            end
        end
    end
    
    if pop(j).b(1,ii)~=0&&pop(j).b(5,ii)~=0
        if pop(j).b(1,ii-1)==0
            pop(j).b(1,ii-1)=pop(j).b(1,ii);
            pop(j).b(1,ii)=0;
        else
            pop(j).b(1,ii-2)=pop(j).b(1,ii-1);
            pop(j).b(1,ii-1)=pop(j).b(1,ii);
            pop(j).b(1,ii)=0;
        end
        
    end
end
 qq=qq+1;
end
if pop(j).b(1,1)~=0
    for ii=DIM1:-1:1
        for jj=DIM9:-1:1
            if pop(j).b(ii,jj)~=0
                pop(j).b(ii,jj+1)=pop(j).b(ii,jj);
                pop(j).b(ii,jj)=0;
            end
        end
    end
end
    %�ҳ��ɿ�����ƶ�������ǰ���ϵ
    E=zeros(DIM3,DIM9);
	Eh=zeros(DIM3,DIM9);%ȥ�����������������õ����м��Ʒ�����
	Ef=zeros(DIM3,DIM9);%ȥ���������������������������������������������õ����м��Ʒ�����
    total_stage=DIM4+stage_material(1);
    for sm=2:DIM11-1
        for r=total_stage+1:total_stage+stage_material(sm)
            E(r,sm-1)=0;
        end
        total_stage=total_stage+stage_material(sm);
    end        %�����������ϵ��м��Ʒ�ۼ�������
    for n=1:DIM9-DIM4+1
        total_stage=DIM4+stage_material(1);
        for sm=2:DIM11-1
            for r=total_stage+1:total_stage+stage_material(sm)
                i1=I(r,1);
                i2=I(r,2);
                E(r,n+sm-1)=E(r,n+sm-2)+pop(j).b(i1,n+sm-2)*beta(i1)-pop(j).b(i2,n+sm-1);
                Ef(r,n+sm-1)= E(r,n+sm-1)+pop(j).b(i2,n+sm-1);
                if(Ef(r,n+sm-1)-Emax(r)>0.5)
                    pop(j).successor(i1,n+sm-2,1)=1;  %no-wait����ȥ��׶ε�����
                elseif(Ef(r,n+sm-1)+pop(j).b(i1,n+sm-1)*beta(i1)-Emax(r)>0.00001&&pop(j).b(i1, n+sm-1)~=0&&pop(j).b(i2,n+sm-1)~=0)
                    pop(j).successor(i1,n+sm-1,2)=1;  %����ǰ�׶ε����¼��������
                end
            end
            total_stage=total_stage+stage_material(sm);
        end
     
    end
    total_stage_task=0;
	for is=1:DIM4		
		ai=0;an=0;
		for n=1:DIM9
			for i=total_stage_task+1:total_stage_task+stage_task(is)

				if(pop(j).b(i,n)~=0&&ai~=0)
					pop(j).aheadi(i,n)=ai;
					pop(j).aheadn(i,n)=an;	
					ai=i+1;
					an=n+1;
				
                elseif(pop(j).b(i,n)~=0&&ai==0)
					ai=i+1;
					an=n+1;	
                end
            end				
        end
		total_stage_task=total_stage_task+stage_task(is);
    end
   
   %%����ģ��
    for i=1:stage_task(1)
        pop(j).tts(i,1)=0;        %����ʼ����ĵ�һ���豸�ĸ�����ĵ�һ��������ֵΪ��
    end
    total_stage_task=stage_task(1);
    for is=2:DIM4
        for i=total_stage_task+1:total_stage_task+stage_task(is)
            for n=1:is
                pop(j).tts(i,n)=0;
            end
        end
        total_stage_task=total_stage_task+stage_task(is);
    end                           %�������Ǹ���ֵΪ��
total_stage_task=stage_task(1);
for is=2:DIM4
    for i=total_stage_task+1:total_stage_task+stage_task(is)
        
        if(pop(j).b(i-DIM6,is-1)~=0)
            pop(j).tts(i,is)=pop(j).tts(i-DIM6,is-1)+pop(j).b(i-DIM6,is-1)*change_task(i-DIM6)+fix_task(i-DIM6);
        else
            pop(j).tts(i,is)=pop(j).tts(i-DIM6,is-1);
        end
    end
    total_stage_task=total_stage_task+stage_task(is);
end%��һ�������һ�豸������������������ǰ����

total_stage_task=total_stage_task-stage_task(DIM4);
for is=DIM4-1:-1:1
    for i=total_stage_task-stage_task(is)+1:total_stage_task
        if(pop(j).successor(i,is,1)==1)
            pop(j).tts(i,is)=pop(j).tts(i+DIM6,is+1)-(pop(j).b(i,is)*change_task(i)+fix_task(i));
        end
    end
    total_stage_task=total_stage_task-stage_task(is);
end%��һ�������һ�豸������������������

for n=2:DIM9-DIM4+1
    total_stage_task=0;
    for is=1:DIM4
        for i=total_stage_task+1:total_stage_task+stage_task(is)
            immediate_t1=0;immediate_t2=0;immediate_t3=0;immediate_t4=0;
            
            if(pop(j).b(i,n+is-2)~=0)
                immediate_t1=pop(j).tts(i,n+is-2)+(pop(j).b(i,n+is-2)*change_task(i)+fix_task(i));
            else
                immediate_t1=pop(j).tts(i,n+is-2);
            end
            if(i-DIM6>=1)
                if(pop(j).b(i-DIM6,n+is-2)~=0)
                    immediate_t2=pop(j).tts(i-DIM6,n+is-2)+(pop(j).b(i-DIM6,n+is-2)*change_task(i-DIM6)+fix_task(i-DIM6));
                else
                    immediate_t2=pop(j).tts(i-DIM6,n+is-2);
                end
            end
            
            if(pop(j).successor(i,n+is-1,2)==1)
                if(pop(j).b(i,n+is-1)~=0)
                    immediate_t3=pop(j).tts(i+DIM6,n+is-1)-(pop(j).b(i,n+is-1)*change_task(i)+fix_task(i));
                else
                    immediate_t3=pop(j).tts(i+DIM6,n+is-1);
                end
            end
            
            if(pop(j).aheadi(i,n+is-1)~=0)
                ai=pop(j).aheadi(i,n+is-1);
                an=pop(j).aheadn(i,n+is-1);
                immediate_t4=pop(j).tts(ai-1,an-1)+(pop(j).b(ai-1,an-1)*change_task(ai-1)+fix_task(ai-1))+change(ai-1);
            end
           
            pop(j).tts(i,n+is-1)=maxx(immediate_t1,immediate_t2,immediate_t3,immediate_t4);
        end
        total_stage_task=total_stage_task+stage_task(is);
    end
    
    total_stage_task=total_stage_task-stage_task(DIM4);
    for is=DIM4-1:-1:1
        for i=total_stage_task-stage_task(is)+1:total_stage_task+stage_task(is)
            if(pop(j).successor(i,n+is-1,1)==1)
                pop(j).tts(i,n+is-1)=pop(j).tts(i+DIM6,n+is)-(pop(j).b(i,n+is-1)*change_task(i)+fix_task(i));
            end
        end
        total_stage_task=total_stage_task-stage_task(is);
    end
end
	%��һ�μ���ĵ�һ��֮��ĸ���
    
    
    if(pop(j).b(DIM1,DIM9)~=0)
        pop(j).Fit1=pop(j).tts( DIM1,DIM9)+(pop(j).b(DIM1,DIM9)*change_task(DIM1)+fix_task(DIM1));
    else
        pop(j).Fit1=pop(j).tts( DIM1,DIM9);
    end
    for i=1:DIM1
        if(pop(j).b(i,DIM9)~=0)
            fff=pop(j).tts(i,DIM9)+(pop(j).b(i,DIM9)*change_task(i)+fix_task(i));
        else
            fff=pop(j).tts(i,DIM9);
        end
        if(pop(j).Fit1<fff)
            pop(j).Fit1=fff;
        end
    end
    


t1=[];count=0;sum1=0;
for jj=1:DIM9
    for ii=1:DIM6
        if pop(j).b(ii,jj)~=0
            t1=[t1 ii];count=count+1;
            if numel(t1)>1&&t1(count-1)~=t1(count)
                sum1=sum1+fix_task(t1(count-1));
            end
        end
    end
end
t2=[];count2=0;sum2=0;
for jj=1:DIM9
    for ii=DIM6+1:DIM6*2
        if pop(j).b(ii,jj)~=0
            t2=[t2 ii];count2=count2+1;
            if numel(t2)>1&&t2(count2-1)~=t2(count2)
                sum2=sum2+fix_task(t2(count2-1));
            end
        end
    end
end
t3=[];count3=0;sum3=0;
for jj=1:DIM9
    for ii=DIM6*2+1:DIM1
        if pop(j).b(ii,jj)~=0
            t3=[t3 ii];count3=count3+1;
            if numel(t3)>1&&t3(count3-1)~=t3(count3)
                sum3=sum3+fix_task(t3(count3-1));
            end
        end
    end
end
pop(j).Fit3=(10*sum1+9*sum2+8*sum3);
 
%  for ii=1:DIM1-DIM6
%      for jj=1:DIM9-1
%          if(pop(j).b(ii,jj)-pop(j).b(ii+DIM6,jj+1)>0);
%              s1=pop(j).b(ii,jj)-pop(j).b(ii+DIM6,jj+1);
%              ss=[ss s1];
%          end
%      end
%  end

 temp=zeros(DIM1,DIM6);ss1=[];
 for ii=1:DIM1
     kk=1;
     for jj=1:DIM9
         if(pop(j).b(ii,jj)~=0)
             temp(ii,kk)=pop(j).b(ii,jj)*beta(ii);ss1=[ss1 jj];
             kk=kk+1;
         end
     end
 end
  ss=[];s1=0;
 for ii=1:4
     if(temp(ii,1)-temp(ii+4,1)>0)
         if(ss1((ii-1)*2+2)>=ss1((ii-1)*2+8+1))
             s1=(temp(ii,1)-temp(ii+4,1));
         else
               s1=(temp(ii,1)+temp(ii,2))-temp(ii+4,1)+temp(ii,1);
         end
     elseif(temp(ii,1)-temp(ii+4,1)<0)
                s1=(temp(ii,1)+temp(ii,2))-temp(ii+4,1)+temp(ii,1);
     elseif(temp(ii,1)-temp(ii+4,1)==0)
         if(ss1((ii-1)*2+2)<ss1((ii-1)*2+8+1))
                s1=(temp(ii,1)+temp(ii,2))-temp(ii+4,1)+temp(ii,1);
         else
             s1=0;
         end
     end
     ss=[ss s1];
 end
 
     sum4=0;
     for ii=1:size(ss,2)
         sum4=sum4+ss(ii);
     end
     pop(j).Fit4=12*sum4+10*(temp(5,1)*beta(5)++temp(6,1)*beta(6)++temp(7,1)*beta(7)+temp(8,1)*beta(8));
    pop(j).Fit2=pop(j).Fit3+pop(j).Fit4;
 
end
z=pop;
end