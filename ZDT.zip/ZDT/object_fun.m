function f = object_fun(x)
       global x_num
% f = [];
%         f(1) = x(1);
%         sum = 0;
%         for i = 2:x_num
%             sum = sum + x(i);
%         end
%         g = 1 + 9 * (sum / (x_num - 1));
%         f(2) = g * (1 - (f(1) / g)^0.5);

% f = [];
%         f(1) = x(1);
%         sum = 0;
%         for i = 2:x_num
%             sum = sum + x(i);
%         end
%         g = 1 + 9 * (sum / (x_num - 1));
%         f(2) = g * (1 - (f(1) / g)^2);

f = [];
        f(1) = x(1);
        sum = 0;
        for i = 2:x_num
            sum = sum + x(i);
        end
        g = 1 + 9 * (sum / (x_num - 1));
        f(2) = g * (1 - (f(1) / g)^0.5-(f(1) / g)*sin(10*pi*f(1)));


end
