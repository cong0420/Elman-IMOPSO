clear; close all; clc
global NP iteration f_num x_num x_min x_max pc pm yita1 yita2 k % ����ȫ�ֱ�����д�ӳ���Ͳ�����ô�鷳��
% NP����Ⱥ��С
% iteration������������
% f_num��Ŀ�����
% x_num�����ά��
% pc��pm�����桢�������
% yita1��yita2��k��GA���·�ʽ��ʽ�õ��Ĳ���
%% ������ʼ��
count=0;
DIM1=12;%������
DIM2=8;%�¼�����
DIM3=19;%��Դ����
DIM4=3;%�豸��Դ��,ÿ�����׶�һ����Դ���ܹ��������׶�����
DIM5= 16;%������Դ��
DIM6= 4;%��Դ�ϵ�������
DIM7= 8;%������Դ��
DIM8=4;%��һ�׶ε�������
DIM9=36;%p.xת��Ϊb��w���ά��
DIM10=4;%���׶ε�������
DIM11=4;%���еĽ׶�֮�����������stnͼ��������ʼ���м�ͽ���������
%%
I=[1,2,3,4;5,6,7,8;9,10,11,12;1,0,0,0;2,0,0,0;3,0,0,0;4,0,0,0;1,5,0,0;2,6,0,0;3,7,0,0;4,8,0,0;5,9,0,0;6,10,0,0;7,11,0,0;8,12,0,0;9,0,0,0;10,0,0,0;11,0,0,0;12,0,0,0];%��Դ�ϵ���������
beta=[1.0,1.0,1.0,1.0,0.9,0.9,0.9,0.9,0.8,0.8,0.8,0.8];
%Emax;��Դ���Ƶ�����
Emin=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];%��Դ���Ƶ�����
resource_restore= [6,7,8,9];%�п�����Ƶ�������Դ
bmin=[5,5,5,5,5,5,5,5,5,5,5,5];%��������������
% bmax=[12.9,12.9,12.9,12.9,17.8,17.8,17.8,17.8,21.5,21.5,21.5,21.5];%��������������
bmax=[14.74,14.74,14.74,14.74,18.05,18.05,18.05,18.05,21.70,21.70,21.70,21.70];%��������������
fix_task=[4,3,5,4.5,3,2.5,2.6,2.8,6,5.5,6.4,5];%����̶�������ʱ��
change_task=[0.1,0.15,0.12,0.13,0.1,0.1,0.21,0.15,0.1,0.11,0.09,0.12];%����䶯������ʱ��
stage_material=[4,4,4,4];%���׶εĲ�Ʒ����
stage_task=[4,4,4];%���׶ε���������
  %demand=[19.44,22.22,20.83,16.67,19.44,22.22,20.83,16.67,17.49,19.99,18.74,15];
 demand=[22.24,20.85,23.64,20.85,22.24,20.85,23.64,20.85,20,18.75,21.25,18.75];
 Emax=[1,1,1,300,300,300,300,16,17,16,16,20,22,21,23,300,300,300,300];
% Emax=[1,1,1,300,300,300,300,23,22.84,22.23,21.06,24.5,25.75,25,26.25,300,300,300,300];
change=[[0,0,0,1,0,0,0,0,0,0,0,0],[0,0,1,0,0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,1,0,0,0,0],[0,0,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,1,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,1,0,0,0],[0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0],[0,0,0,0,0,0,0,0,0,0,0,1]];


%%%%1.����һ�������ṹ�壻
POP.X = zeros(DIM1,DIM2);
POP.V = zeros(DIM1,DIM2);
POP.Best.X=zeros(DIM1,DIM2);
POP.Best.b=zeros(DIM1,DIM9);
POP.Best.tts=zeros(DIM1,DIM9);
POP.Best.FIT=zeros(2,1);
POP.Best.Fit1=0;
POP.Best.Fit2=0;
POP.FIT=zeros(2,1);
POP.Fit1=0;
POP.Fit2=0;POP.Fit3=0;POP.Fit4=0;
POP.b= zeros(DIM1,DIM9);
POP.bBest= zeros(DIM1,DIM9);
POP.successor= zeros(DIM1,DIM9,2);
POP.aheadi= zeros(DIM1,DIM9);
POP.aheadn= zeros(DIM1,DIM9);
POP.tts= zeros(DIM1,DIM9);
POP.ttsBest= zeros(DIM1,DIM9);
POP.IsDominated=[];   % �Ƿ��֧��⣬֧���=1, ��֧���=0
POP.GridIndex=[];     % ��֧�������񻯲���ֵ-������ѭ����������Ŀ�꺯�������л��ڣ�
POP.GridSubIndex=[];  % ÿһ����֧������������ֵ����չȡֵ��Χ�ڣ�
POP.S=[];
POP.R=[];
POP.sigma=[];
POP.sigmaK=[];
POP.D=[];
POP.F=[];
POP.Cost=[];POP.CH=[];
POP.g=[];
%% ���Ժ������������£�
f_num = 2; % Ŀ�꺯������
x_num = 96; % ���߱�������
x_min = zeros(1,x_num); % ���߱�������Сֵ
x_max = [15*ones(1,32),20*ones(1,32),25*ones(1,32)]; % ���߱��������ֵ
te=[];te1=[];
NP =100;
iteration= 100;
k = ceil(NP/5);
yita1 =15; yita2 =15;
pc = 0.6; pm = 0.08;
%% ���Ժ������������£�

nArchive=20;        % Archive Size

K=round(sqrt(NP+nArchive));  % KNN Parameter

pCrossover=pc;
nCrossover=round(pCrossover*NP/2)*2;

pMutation=pm;
nMutation=NP-nCrossover;

crossover_params.gamma=0.1;
crossover_params.VarMin=5;
crossover_params.VarMax=15;

mutation_params.h=0.2;
mutation_params.VarMin=5;
mutation_params.VarMax=15;
archive=[];
%% MOEA/D Settings
nObj=2;
T=max(ceil(0.15*NP),2);    % Number of Neighbors
T=min(max(T,2),15);
%% Initialization
% Create Sub-problems
sp=CreateSubProblems(nObj,NP,T);
% Initialize Goal Point
z=zeros(nObj,1);
%��Ⱥ
nRep=NP/2;    % Repository Size ��֧�����Ⱥ����
nGrid=8;      % Number of Grids per Dimension ÿ��Ŀ�꺯���⼯�����չ�����С����������
alpha=0.25;    % Inflation Rate ��֧���Ľ⼯����չ����

beta=4;       % Leader Selection Pressure   ��֧����ѡ������
gamma=2;      % Deletion Selection Pressure ��֧������̭����
c1 = 2.1;
c2 = 2.2;

w=0.5;
VarSize=[DIM1 DIM2];
popp=chushihua();
for ii=1:DIM1
    for jj=1:DIM2
        Xup(ii,jj)= bmax(ii);
        Xdown(ii,jj)=bmin(ii);
        Vmax(ii,jj)=bmax(ii)-bmin(ii);
    end
end
for j=1:NP
            popp(j).FIT =[popp(j).Fit1,popp(j).Fit2]';
             popp(j).Best.FIT=popp(j).FIT ;
end

    popp=DetermineDomination(popp);  % ȷ����Ⱥ֮���Ƿ����֧���
    
    repp=popp(~[popp.IsDominated]);   % Ȼ���ȡ��֧���
    
    Grid=CreateGrid(repp,nGrid,alpha);  % ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
   
    for i=1:numel(repp)
        repp(i)=FindGridIndex(repp(i),Grid);  % ������չ��֧����GridIndex
    end

%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%MOPSO
% pop2=popp;
% rep2=repp;
% for it=1:iteration
%      % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
%         leader=SelectLeader(rep2,beta);  
%     for i=1:NP
%        
%        %��������
%         %�ٶȸ���
%         pop2(i).V =(w*pop2(i).V ...
%             +c1*rand(VarSize).*(pop2(i).Best.X-pop2(i).X) ...
%             +c2*rand(VarSize).*(leader.X-pop2(i).X));
%         % ����λ�ø���
%         pop2(i).X = pop2(i).X + pop2(i).V;
%         % ����ȡֵ��ΧԼ��
%         for ii=1:DIM1
%             for jj=1:DIM2
%                 if(ii<=DIM6)
%                     pop2(i).X(ii,jj)= min(pop2(i).X(ii,jj), bmax(ii));
%                     pop2(i).X(ii,jj)= max(pop2(i).X(ii,jj), 5);
%                 elseif(ii>DIM6&&ii<=DIM6*2)
%                     pop2(i).X(ii,jj)= min(pop2(i).X(ii,jj), bmax(ii));
%                     pop2(i).X(ii,jj)= max(pop2(i).X(ii,jj), 5);
%                 else
%                     pop2(i).X(ii,jj)= min(pop2(i).X(ii,jj), bmax(ii));
%                     pop2(i).X(ii,jj)= max(pop2(i).X(ii,jj), 5);
%                 end
%             end
%         end
%     end
%     pop2=yueshu(pop2);
%     for i=1:NP
%         pop2(i).FIT=[pop2(i).Fit1,pop2(i).Fit2]';
%         if Dominates(pop2(i),pop2(i).Best)%����pop(i).Best
%             pop2(i).Best.X=pop2(i).X;
%             pop2(i).Best.FIT=pop2(i).FIT;
%         end
%     end
%     % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
%     rep2=[rep2
%          pop2(~[pop2.IsDominated])]; 
%     
%     % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
%     rep2=DetermineDomination(rep2);
%     
%     % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
%     rep2=rep2(~[rep2.IsDominated]);
%     
%     % Update Grid 
%     Grid=CreateGrid(rep2,nGrid,alpha);
% 
%     % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
%     for i=1:numel(rep2)
%         rep2(i)=FindGridIndex(rep2(i),Grid);
%     end
%     
%     % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
%     if numel(rep2)>nRep
%         % ����������Ⱥɾ��
%         Extra=numel(rep2)-nRep;
%         for e=1:Extra
%             rep2=DeleteOneRepMemebr(rep2,gamma);
%         end
%         
%     end
%     
%     
% end
% xx=[];
% %     for i=1:numel(rep2)
% %         for j=1:numel(rep2)
% %             if(rep2(i).FIT(1)>rep2(j).FIT(1)&&rep2(i).FIT(2)>rep2(j).FIT(2))
% %                 xx=[xx i];
% %             end
% %         end
% %     end
%     for i=1:numel(rep2)-1
%         for j=i+1:numel(rep2)
%             if(rep2(i).FIT(1)>=rep2(j).FIT(1)&&rep2(i).FIT(2)>=rep2(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep2(xx)=[];
%   end
% rep_costs=[rep2.FIT];
%         figure(1)  
%         plot(rep_costs(1,:),rep_costs(2,:),'mo');
%          xlabel('1^{st} Objective');
%          ylabel('2^{nd} Objective');
%       
%         hold on; 
%     
%  disp '*************best particle number****************'
% numel(rep2)
% rep2.FIT
% rep2.Fit3
% rep2.Fit4
% rep2.b
% rep2.tts
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case2
% pop22=popp;
% rep22=repp;
% for it=1:iteration
%      % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
%         leader=SelectLeader(rep22,beta);  
%     for i=1:NP
%        
%        %��������
%         %�ٶȸ���
%         pop22(i).V =(w*pop22(i).V ...
%             +c1*rand(VarSize).*(pop22(i).Best.X-pop22(i).X) ...
%             +c2*rand(VarSize).*(leader.X-pop22(i).X));
%         % ����λ�ø���
%         pop22(i).X = pop22(i).X + pop22(i).V;
%         % ����ȡֵ��ΧԼ��
%         for ii=1:DIM1
%             for jj=1:DIM2
%                 if(ii<=DIM6)
%                     pop22(i).X(ii,jj)= min(pop22(i).X(ii,jj), bmax(ii));
%                     pop22(i).X(ii,jj)= max(pop22(i).X(ii,jj), 5);
%                 elseif(ii>DIM6&&ii<=DIM6*2)
%                     pop22(i).X(ii,jj)= min(pop22(i).X(ii,jj), bmax(ii));
%                     pop22(i).X(ii,jj)= max(pop22(i).X(ii,jj), 5);
%                 else
%                     pop22(i).X(ii,jj)= min(pop22(i).X(ii,jj), bmax(ii));
%                     pop22(i).X(ii,jj)= max(pop22(i).X(ii,jj), 5);
%                 end
%             end
%         end
%     end
%     pop22=yueshu2(pop22);
%     for i=1:NP
%         pop22(i).FIT=[pop22(i).Fit1,pop22(i).Fit2]';
%         if Dominates(pop22(i),pop22(i).Best)%����pop(i).Best
%             pop22(i).Best.X=pop22(i).X;
%             pop22(i).Best.FIT=pop22(i).FIT;
%         end
%     end
%     % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
%     rep22=[rep22
%          pop22(~[pop22.IsDominated])]; 
%     
%     % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
%     rep22=DetermineDomination(rep22);
%     
%     % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
%     rep22=rep22(~[rep22.IsDominated]);
%     
%     % Update Grid 
%     Grid=CreateGrid(rep22,nGrid,alpha);
% 
%     % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
%     for i=1:numel(rep22)
%         rep22(i)=FindGridIndex(rep22(i),Grid);
%     end
%     
%     % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
%     if numel(rep22)>nRep
%         % ����������Ⱥɾ��
%         Extra=numel(rep22)-nRep;
%         for e=1:Extra
%             rep22=DeleteOneRepMemebr(rep22,gamma);
%         end
%         
%     end
%     
%     
% end
% xx=[];
%     for i=1:numel(rep22)-1
%         for j=i+1:numel(rep22)
%             if(rep22(i).FIT(1)>=rep22(j).FIT(1)&&rep22(i).FIT(2)>=rep22(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep22(xx)=[];
%   end
% rep_costs=[rep22.FIT];
%         figure(1)  
%         plot(rep_costs(1,:),rep_costs(2,:),'r<');
%          xlabel('1^{st} Objective');
%          ylabel('2^{nd} Objective');
%       
%         hold on; 
%     
%  disp '*************best particle number****************'
% numel(rep22)
% rep22.FIT
% rep22.Fit3
% rep22.Fit4
% rep22.b
% rep22.tts
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case3
% pop23=popp;rep23=repp;
% for it=1:iteration
%      % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
%         leader=SelectLeader(rep23,beta);  
%     for i=1:NP
%        
%        %��������
%         %�ٶȸ���
%         pop23(i).V =(w*pop23(i).V ...
%             +c1*rand(VarSize).*(pop23(i).Best.X-pop23(i).X) ...
%             +c2*rand(VarSize).*(leader.X-pop23(i).X));
%         % ����λ�ø���
%         pop23(i).X = pop23(i).X + pop23(i).V;
%         % ����ȡֵ��ΧԼ��
%         for ii=1:DIM1
%             for jj=1:DIM2
%                 if(ii<=DIM6)
%                     pop23(i).X(ii,jj)= min(pop23(i).X(ii,jj), bmax(ii));
%                     pop23(i).X(ii,jj)= max(pop23(i).X(ii,jj), 5);
%                 elseif(ii>DIM6&&ii<=DIM6*2)
%                     pop23(i).X(ii,jj)= min(pop23(i).X(ii,jj), bmax(ii));
%                     pop23(i).X(ii,jj)= max(pop23(i).X(ii,jj), 5);
%                 else
%                     pop23(i).X(ii,jj)= min(pop23(i).X(ii,jj), bmax(ii));
%                     pop23(i).X(ii,jj)= max(pop23(i).X(ii,jj), 5);
%                 end
%             end
%         end
%     end
%     pop23=yueshu(pop23);
%     for i=1:NP
%         pop23(i).FIT=[pop23(i).Fit1,pop23(i).Fit2]';
%         if Dominates(pop23(i),pop23(i).Best)%����pop(i).Best
%             pop23(i).Best.X=pop23(i).X;
%             pop23(i).Best.FIT=pop23(i).FIT;
%         end
%     end
%     for i=1:NP
%         pop23(i).Fit2=pop23(i).Fit4;
%         pop23(i).FIT=[pop23(i).Fit1,pop23(i).Fit2]';
%     end
%     % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
%     rep23=[rep23
%          pop23(~[pop23.IsDominated])]; 
%     
%     % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
%     rep23=DetermineDomination(rep23);
% 
%     % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
%     rep23=rep23(~[rep23.IsDominated]);
%     
%     % Update Grid 
%     Grid=CreateGrid(rep23,nGrid,alpha);
% 
%     % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
%     for i=1:numel(rep23)
%         rep23(i)=FindGridIndex(rep23(i),Grid);
%     end
%     
%     % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
%     if numel(rep23)>nRep
%         % ����������Ⱥɾ��
%         Extra=numel(rep23)-nRep;
%         for e=1:Extra
%             rep23=DeleteOneRepMemebr(rep23,gamma);
%         end
%         
%     end
%     for i=1:numel(rep23)
%         rep23(i).Fit2=rep23(i).Fit4+rep23(i).Fit3;
%         rep23(i).FIT=[rep23(i).Fit1,rep23(i).Fit2]';
%     end
%     for i=1:NP
%         pop23(i).Fit2=pop23(i).Fit2+pop23(i).Fit3;
%         pop23(i).FIT=[pop23(i).Fit1,pop23(i).Fit2]';
%     end
% end
% xx=[];
% %     for i=1:numel(rep2)
% %         for j=1:numel(rep2)
% %             if(rep2(i).FIT(1)>rep2(j).FIT(1)&&rep2(i).FIT(2)>rep2(j).FIT(2))
% %                 xx=[xx i];
% %             end
% %         end
% %     end
%     for i=1:numel(rep23)-1
%         for j=i+1:numel(rep23)
%             if(rep23(i).FIT(1)>=rep23(j).FIT(1)&&rep23(i).FIT(2)>=rep23(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep23(xx)=[];
%   end
% rep_costs=[rep23.FIT];
%         figure(1)  
%         plot(rep_costs(1,:),rep_costs(2,:),'b*');
%          xlabel('1^{st} Objective');
%          ylabel('2^{nd} Objective');
%       
%         hold on; 
%     
%  disp '*************best particle number****************'
% numel(rep23)
% rep23.FIT
% rep23.Fit3
% rep23.Fit4
% rep23.b
% rep23.tts
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%IMOPSO
pop1=popp;
rep1=repp;
for i=1:NP
    pop1(i).g=DecomposedCost(pop1(i),z,sp(i).lambda);
end
for it=1:iteration
     % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
        leader=SelectLeader(rep1,beta);  
    for i=1:NP
       
       %��������
        %�ٶȸ���
        pop1(i).V =(w*pop1(i).V ...
            +c1*rand(VarSize).*(pop1(i).Best.X-pop1(i).X) ...
            +c2*rand(VarSize).*(leader.X-pop1(i).X));
        % ����λ�ø���
        pop1(i).X = pop1(i).X + pop1(i).V;
        % ����ȡֵ��ΧԼ��
        for ii=1:DIM1
            for jj=1:DIM2
                if(ii<=DIM6)
                    pop1(i).X(ii,jj)= min(pop1(i).X(ii,jj), bmax(ii));
                    pop1(i).X(ii,jj)= max(pop1(i).X(ii,jj), 5);
                elseif(ii>DIM6&&ii<=DIM6*2)
                    pop1(i).X(ii,jj)= min(pop1(i).X(ii,jj), bmax(ii));
                    pop1(i).X(ii,jj)= max(pop1(i).X(ii,jj), 5);
                else
                    pop1(i).X(ii,jj)= min(pop1(i).X(ii,jj), bmax(ii));
                    pop1(i).X(ii,jj)= max(pop1(i).X(ii,jj), 5);
                end
            end
        end
    end
    pop1=yueshu(pop1);
    for i=1:NP
        pop1(i).FIT=[pop1(i).Fit1,pop1(i).Fit2]';
        if Dominates(pop1(i),pop1(i).Best)%����pop(i).Best
            pop1(i).Best.X=pop1(i).X;
            pop1(i).Best.FIT=pop1(i).FIT;
        end
        % Reproduction (Crossover)
           K=randsample(T,2);
           
           j1=sp(i).Neighbors(K(1));
           p1=pop1(j1);
           
           j2=sp(i).Neighbors(K(2));
           p2=pop1(j2);
           
           y=POP; 
           pp1=zeros(1,x_num);pp2=zeros(1,x_num);
           for ii=1:DIM1
               for jj=1:DIM2
                   if(ii==1)
                       pp1(jj) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==2)
                       pp1(jj+8) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==3)
                        pp1(jj+16) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==4)
                        pp1(jj+24) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==5)
                       pp1(jj+32) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==6)
                        pp1(jj+40) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==7)
                        pp1(jj+48) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==8)
                        pp1(jj+56) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==9)
                        pp1(jj+64) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==10)
                        pp1(jj+72) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   elseif(ii==11)
                        pp1(jj+80) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   else
                        pp1(jj+88) =p1.X(ii,jj);pp2(jj) =p2.X(ii,jj);
                   end
               end
           end
           chromo_off1=CCrossover(pp1,pp2);
           
               for d=1:x_num
                   if(d<=8)
                       y.X(1,d)=chromo_off1(d);
                   elseif(d>8&&d<=16)
                       y.X(2,d-8)=chromo_off1(d);
                   elseif(d>16&&d<=24)
                       y.X(3,d-16)=chromo_off1(d);
                   elseif(d>24&&d<=32)
                       y.X(4,d-24)=chromo_off1(d);
                   elseif(d>32&&d<=40)
                       y.X(5,d-32)=chromo_off1(d);
                   elseif(d>40&&d<=48)
                       y.X(6,d-40)=chromo_off1(d);
                   elseif(d>48&&d<=56)
                       y.X(7,d-48)=chromo_off1(d);
                   elseif(d>56&&d<=64)
                       y.X(8,d-56)=chromo_off1(d);
                   elseif(d>64&&d<=72)
                       y.X(9,d-64)=chromo_off1(d);
                   elseif(d>72&&d<=80)
                       y.X(10,d-72)=chromo_off1(d);
                   elseif(d>80&&d<=88)
                       y.X(11,d-80)=chromo_off1(d);
                   else
                       y.X(12,d-88)=chromo_off1(d);
                   end
               end   

              y=bys(y);
           y.FIT=[y.Fit1,y.Fit2]';
           z=min(z,y.FIT);

               for j=sp(i).Neighbors
                   y.g=DecomposedCost(y,z,sp(j).lambda);
                   if y.g<=pop1(j).g
                       pop1(j)=y;
                       if Dominates(pop1(j),pop1(j).Best)%����pop(j).Best
                           pop1(j).Best.X=pop1(j).X;
                           pop1(j).Best.FIT=pop1(j).FIT;
                       end
                   end
               end
             end

   % Determine Population Domination Status
       pop1=DetermineDomination(pop1);
       
       ndpop=pop1(~[pop1.IsDominated]);
       
       rep1=[rep1
           ndpop]; %#ok
    

    % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
    rep1=[rep1
         pop1(~[pop1.IsDominated])]; 
    
    % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
    rep1=DetermineDomination(rep1);
    
    % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
    rep1=rep1(~[rep1.IsDominated]);
    
    % Update Grid 
    Grid=CreateGrid(rep1,nGrid,alpha);

    % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
    for i=1:numel(rep1)
        rep1(i)=FindGridIndex(rep1(i),Grid);
    end
    
    % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
    if numel(rep1)>nRep
        % ����������Ⱥɾ��
        Extra=numel(rep1)-nRep;
        for e=1:Extra
            rep1=DeleteOneRepMemebr(rep1,gamma);
        end
        
    end
    
    
end
% xx=[];
%     for i=1:numel(rep1)-1
%         for j=i+1:numel(rep1)
%             if(rep1(i).FIT(1)>=rep1(j).FIT(1)&&rep1(i).FIT(2)>=rep1(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep1(xx)=[];
%   end
rep_costs=[rep1.FIT];
        figure(1)  
        plot(rep_costs(1,:),rep_costs(2,:),'mo');
         xlabel('1^{st} Objective');
         ylabel('2^{nd} Objective');
      
        hold on; 
    
 disp '*************best particle number****************'
numel(rep1)
rep1.FIT
rep1.Fit3
rep1.Fit4
rep1.b
rep1.tts
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case2
pop12=popp;
rep12=repp;
for i=1:NP
    pop12(i).g=DecomposedCost(pop12(i),z,sp(i).lambda);
end
for it=1:iteration
     % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
        leader=SelectLeader(rep12,beta);  
    for i=1:NP
       
       %��������
        %�ٶȸ���
        pop12(i).V =(w*pop12(i).V ...
            +c1*rand(VarSize).*(pop12(i).Best.X-pop12(i).X) ...
            +c2*rand(VarSize).*(leader.X-pop12(i).X));
        % ����λ�ø���
        pop12(i).X = pop12(i).X + pop12(i).V;
        % ����ȡֵ��ΧԼ��
        for ii=1:DIM1
            for jj=1:DIM2
                if(ii<=DIM6)
                    pop12(i).X(ii,jj)= min(pop12(i).X(ii,jj), bmax(ii));
                    pop12(i).X(ii,jj)= max(pop12(i).X(ii,jj), 5);
                elseif(ii>DIM6&&ii<=DIM6*2)
                    pop12(i).X(ii,jj)= min(pop12(i).X(ii,jj), bmax(ii));
                    pop12(i).X(ii,jj)= max(pop12(i).X(ii,jj), 5);
                else
                    pop12(i).X(ii,jj)= min(pop12(i).X(ii,jj), bmax(ii));
                    pop12(i).X(ii,jj)= max(pop12(i).X(ii,jj), 5);
                end
            end
        end
    end
    pop12=yueshu2(pop12);
    for i=1:NP
        pop12(i).FIT=[pop12(i).Fit1,pop12(i).Fit2]';
        if Dominates(pop12(i),pop12(i).Best)%����pop(i).Best
            pop12(i).Best.X=pop12(i).X;
            pop12(i).Best.FIT=pop12(i).FIT;
        end
        % Reproduction (Crossover)
           K=randsample(T,2);
           
           j12=sp(i).Neighbors(K(1));
           p12=pop12(j12);
           
           j22=sp(i).Neighbors(K(2));
           p22=pop12(j22);
           
           y2=POP; 
           pp12=zeros(1,x_num);pp22=zeros(1,x_num);
           for ii=1:DIM1
               for jj=1:DIM2
                   if(ii==1)
                       pp12(jj) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==2)
                       pp12(jj+8) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==3)
                        pp12(jj+16) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==4)
                        pp12(jj+24) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==5)
                       pp12(jj+32) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==6)
                        pp12(jj+40) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==7)
                        pp12(jj+48) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==8)
                        pp12(jj+56) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==9)
                        pp12(jj+64) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==10)
                        pp12(jj+72) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   elseif(ii==11)
                        pp12(jj+80) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   else
                        pp12(jj+88) =p12.X(ii,jj);pp22(jj) =p22.X(ii,jj);
                   end
               end
           end
           chromo_off12=CCrossover(pp12,pp22);
           
               for d=1:x_num
                   if(d<=8)
                       y2.X(1,d)=chromo_off12(d);
                   elseif(d>8&&d<=16)
                       y2.X(2,d-8)=chromo_off12(d);
                   elseif(d>16&&d<=24)
                       y2.X(3,d-16)=chromo_off12(d);
                   elseif(d>24&&d<=32)
                       y2.X(4,d-24)=chromo_off12(d);
                   elseif(d>32&&d<=40)
                       y2.X(5,d-32)=chromo_off12(d);
                   elseif(d>40&&d<=48)
                       y2.X(6,d-40)=chromo_off12(d);
                   elseif(d>48&&d<=56)
                       y2.X(7,d-48)=chromo_off12(d);
                   elseif(d>56&&d<=64)
                       y2.X(8,d-56)=chromo_off12(d);
                   elseif(d>64&&d<=72)
                       y2.X(9,d-64)=chromo_off12(d);
                   elseif(d>72&&d<=80)
                       y2.X(10,d-72)=chromo_off12(d);
                   elseif(d>80&&d<=88)
                       y2.X(11,d-80)=chromo_off12(d);
                   else
                       y2.X(12,d-88)=chromo_off12(d);
                   end
               end   

              y2=bys2(y2);
           y2.FIT=[y2.Fit1,y2.Fit2]';
           z=min(z,y2.FIT);

               for j=sp(i).Neighbors
                   y2.g=DecomposedCost(y2,z,sp(j).lambda);
                   if y2.g<=pop12(j).g
                       pop12(j)=y2;
                       if Dominates(pop12(j),pop12(j).Best)%����pop(j).Best
                           pop12(j).Best.X=pop12(j).X;
                           pop12(j).Best.FIT=pop12(j).FIT;
                       end
                   end
               end
             end

   % Determine Population Domination Status
       pop12=DetermineDomination(pop12);
       
       ndpop=pop12(~[pop12.IsDominated]);
       
       rep12=[rep12
           ndpop]; %#ok
    

    % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
    rep12=[rep12
         pop12(~[pop12.IsDominated])]; 
    
    % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
    rep12=DetermineDomination(rep12);
    
    % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
    rep12=rep12(~[rep12.IsDominated]);
    
    % Update Grid 
    Grid=CreateGrid(rep12,nGrid,alpha);

    % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
    for i=1:numel(rep12)
        rep12(i)=FindGridIndex(rep12(i),Grid);
    end
    
    % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
    if numel(rep12)>nRep
        % ����������Ⱥɾ��
        Extra=numel(rep12)-nRep;
        for e=1:Extra
            rep12=DeleteOneRepMemebr(rep12,gamma);
        end
        
    end
    
    
end
% xx=[];
%     for i=1:numel(rep12)-1
%         for j=i+1:numel(rep12)
%             if(rep12(i).FIT(1)>=rep12(j).FIT(1)&&rep12(i).FIT(2)>=rep12(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep12(xx)=[];
%   end
rep_costs=[rep12.FIT];
        figure(1)  
        plot(rep_costs(1,:),rep_costs(2,:),'r<');
         xlabel('1^{st} Objective');
         ylabel('2^{nd} Objective');
      
        hold on; 
    
 disp '*************best particle number****************'
numel(rep12)
rep12.FIT
rep12.Fit3
rep12.Fit4
rep12.b
rep12.tts
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%case3
pop13=popp;
rep13=repp;
for i=1:NP
    pop13(i).g=DecomposedCost(pop13(i),z,sp(i).lambda);
end
for it=1:iteration
     % ���̶��������ѡ��һ����֧��⣬�Ŷ��⣬��������ֲ�����;��ѡ���쵼��
        leader=SelectLeader(rep13,beta);  
    for i=1:NP
       
       %��������
        %�ٶȸ���
        pop13(i).V =(w*pop13(i).V ...
            +c1*rand(VarSize).*(pop13(i).Best.X-pop13(i).X) ...
            +c2*rand(VarSize).*(leader.X-pop13(i).X));
        % ����λ�ø���
        pop13(i).X = pop13(i).X + pop13(i).V;
        % ����ȡֵ��ΧԼ��
        for ii=1:DIM1
            for jj=1:DIM2
                if(ii<=DIM6)
                    pop13(i).X(ii,jj)= min(pop13(i).X(ii,jj), bmax(ii));
                    pop13(i).X(ii,jj)= max(pop13(i).X(ii,jj), 5);
                elseif(ii>DIM6&&ii<=DIM6*2)
                    pop13(i).X(ii,jj)= min(pop13(i).X(ii,jj), bmax(ii));
                    pop13(i).X(ii,jj)= max(pop13(i).X(ii,jj), 5);
                else
                    pop13(i).X(ii,jj)= min(pop13(i).X(ii,jj), bmax(ii));
                    pop13(i).X(ii,jj)= max(pop13(i).X(ii,jj), 5);
                end
            end
        end
    end
    pop13=yueshu(pop13);
    for i=1:NP
        pop13(i).FIT=[pop13(i).Fit1,pop13(i).Fit2]';
        if Dominates(pop13(i),pop13(i).Best)%����pop(i).Best
            pop13(i).Best.X=pop13(i).X;
            pop13(i).Best.FIT=pop13(i).FIT;
        end
        % Reproduction (Crossover)
           K=randsample(T,2);
           
           j13=sp(i).Neighbors(K(1));
           p13=pop13(j13);
           
           j23=sp(i).Neighbors(K(2));
           p23=pop13(j23);
           
           y3=POP; 
           pp13=zeros(1,x_num);pp23=zeros(1,x_num);
           for ii=1:DIM1
               for jj=1:DIM2
                   if(ii==1)
                       pp13(jj) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==2)
                       pp13(jj+8) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==3)
                        pp13(jj+16) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==4)
                        pp13(jj+24) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==5)
                       pp13(jj+32) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==6)
                        pp13(jj+40) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==7)
                        pp13(jj+48) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==8)
                        pp13(jj+56) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==9)
                        pp13(jj+64) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==10)
                        pp13(jj+72) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   elseif(ii==11)
                        pp13(jj+80) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   else
                        pp13(jj+88) =p13.X(ii,jj);pp23(jj) =p23.X(ii,jj);
                   end
               end
           end
           chromo_off13=CCrossover(pp13,pp23);
           
               for d=1:x_num
                   if(d<=8)
                       y3.X(1,d)=chromo_off13(d);
                   elseif(d>8&&d<=16)
                       y3.X(2,d-8)=chromo_off13(d);
                   elseif(d>16&&d<=24)
                       y3.X(3,d-16)=chromo_off13(d);
                   elseif(d>24&&d<=32)
                       y3.X(4,d-24)=chromo_off13(d);
                   elseif(d>32&&d<=40)
                       y3.X(5,d-32)=chromo_off13(d);
                   elseif(d>40&&d<=48)
                       y3.X(6,d-40)=chromo_off13(d);
                   elseif(d>48&&d<=56)
                       y3.X(7,d-48)=chromo_off13(d);
                   elseif(d>56&&d<=64)
                       y3.X(8,d-56)=chromo_off13(d);
                   elseif(d>64&&d<=72)
                       y3.X(9,d-64)=chromo_off13(d);
                   elseif(d>72&&d<=80)
                       y3.X(10,d-72)=chromo_off13(d);
                   elseif(d>80&&d<=88)
                       y3.X(11,d-80)=chromo_off13(d);
                   else
                       y3.X(12,d-88)=chromo_off13(d);
                   end
               end   

              y3=bys(y3);
           y3.FIT=[y3.Fit1,y3.Fit2]';
           z=min(z,y3.FIT);

               for j=sp(i).Neighbors
                   y3.g=DecomposedCost(y3,z,sp(j).lambda);
                   if y3.g<=pop13(j).g
                       pop13(j)=y3;
                       if Dominates(pop13(j),pop13(j).Best)%����pop(j).Best
                           pop13(j).Best.X=pop13(j).X;
                           pop13(j).Best.FIT=pop13(j).FIT;
                       end
                   end
               end
             end
    for i=1:NP
        pop13(i).Fit2=pop13(i).Fit4;
        pop13(i).FIT=[pop13(i).Fit1,pop13(i).Fit2]';
    end

   % Determine Population Domination Status
       pop13=DetermineDomination(pop13);
       
       ndpop=pop13(~[pop13.IsDominated]);
       
       rep13=[rep13
           ndpop]; %#ok
    

    % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
    rep13=[rep13
         pop13(~[pop13.IsDominated])]; 
    
    % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
    rep13=DetermineDomination(rep13);
    
    % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
    rep13=rep13(~[rep13.IsDominated]);
    
    for i=1:NP
        pop13(i).Fit2=pop13(i).Fit4+pop13(i).Fit3;
        pop13(i).FIT=[pop13(i).Fit1,pop13(i).Fit2]';
    end
    for i=1:numel(rep13)
        rep13(i).Fit2=rep13(i).Fit4+rep13(i).Fit3;
        rep13(i).FIT=[rep13(i).Fit1,rep13(i).Fit2]';
    end
    % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
    rep13=DetermineDomination(rep13);
    
    % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
    rep13=rep13(~[rep13.IsDominated]);
    
    % Update Grid 
    Grid=CreateGrid(rep13,nGrid,alpha);

    % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
    for i=1:numel(rep13)
        rep13(i)=FindGridIndex(rep13(i),Grid);
    end
    
    % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
    if numel(rep13)>nRep
        % ����������Ⱥɾ��
        Extra=numel(rep13)-nRep;
        for e=1:Extra
            rep13=DeleteOneRepMemebr(rep13,gamma);
        end
        
    end


end
% xx=[];
%     for i=1:numel(rep13)-1
%         for j=i+1:numel(rep13)
%             if(rep13(i).FIT(1)>=rep13(j).FIT(1)&&rep13(i).FIT(2)>=rep13(j).FIT(2))
%                 xx=[xx i];
%             end
%         end
%     end
%   for i=numel(xx)
%       rep13(xx)=[];
%   end
rep_costs=[rep13.FIT];
        figure(1)  
        plot(rep_costs(1,:),rep_costs(2,:),'b*');
         xlabel('1^{st} Objective');
         ylabel('2^{nd} Objective');
      
        hold on; 
    
 disp '*************best particle number****************'
numel(rep13)
rep13.FIT
rep13.Fit3
rep13.Fit4
rep13.b
rep13.tts
  legend('case1','case2','case3');
