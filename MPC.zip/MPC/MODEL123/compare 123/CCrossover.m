%
% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YOEA122
% Project Title: Strength Pareto Evolutionary Algorithm 2 (SPEA2)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

function y=CCrossover(off_1,off_2)

   global nPop f_num x_num x_min x_max pc yita1
 y=off_1;
    if rand < pc
   
% ÿһά������ʽ�������¡���
            for j = 1:x_num
                u = rand;
                if u < 0.5
                    gama = (2 * u)^(1 / (yita1 + 1));
                else
                    gama = (1 / (2 * (1 - u)))^(1 / (yita1+1));
                end
                if off_1(j)~=0&&off_2(j)~=0
                y(j) = 0.5 * ((1 + gama) * off_1(j) + (1 - gama) * off_2(j));
                end
            end
           
        for j=1:x_num
            if(y(j)> x_max(j))
                y(j)=x_max(j);
            elseif(y(j)< x_min(j))
                y(j)=x_min(j);
            end
        end
    end

end



