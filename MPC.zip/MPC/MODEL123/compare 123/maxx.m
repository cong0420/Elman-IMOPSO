function z = maxx(x1,x2,x3,x4)

if(x1>x2)
    maxvallue=x1;
else
    maxvallue=x2;
end
if(x3>maxvallue)
    maxvallue=x3;
end
if(x4>maxvallue)
    maxvallue=x4;
end

z=maxvallue;


end
