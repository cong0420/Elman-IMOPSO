%% PSO
%% ��ջ���
clc
clear
close all
warning off
%% ������ʼ��
count=0;
DIM1=6;%������
DIM2=4;%�¼�����
DIM3= 11;%��Դ����
DIM4=3;%�豸��Դ��,ÿ�����׶�һ����Դ���ܹ��������׶�����
DIM5= 8;%������Դ��
DIM6= 2;%��Դ�ϵ�������
DIM7= 4;%������Դ��
DIM8=2;%��һ�׶ε�������
DIM9=6;%p.xת��Ϊb��w���ά��
DIM10= 2;%���׶ε�������
DIM11= 4;%���еĽ׶�֮�����������stnͼ��������ʼ���м�ͽ���������
%%
I=[1,2;3,4;5,6;1,0;2,0;1,3;2,4;3,5;4,6;5,0;6,0];%��Դ�ϵ���������
%Emax;��Դ���Ƶ�����
Emin=[0,0,0,0,0,0,0,0,0,0,0];%��Դ���Ƶ�����
resource_restore= [6,7,8,9];%�п�����Ƶ�������Դ
bmin=[5,5,5,5,5,5];%��������������
bmax=[150,150,150,150,150,150];%��������������
fix_task=[10,10,10,10,10,10];%����̶�������ʱ��
change_task=[1,1,1,1,1,1];%����䶯������ʱ��
stage_material=[2,2,2,2];%���׶εĲ�Ʒ����
stage_task=[2,2,2];%���׶ε���������
demand=[300,300,300,300,300,300];
Emax=[1,1,1,500,500,300,300,300,300,500,500];
change=[[0,1,0,0,0,0],[1,0,0,0,0,0],[0,0,0,1,0,0],[0,0,1,0,0,0],[0,0,0,0,0,1],[0,0,0,0,1,0]];
%%
%����Ⱥ�㷨�е���������
c1 = 1;
c2 = 2;

maxgen=10;   % ��������  
sizepop=10;   %��Ⱥ��ģ

%���Ӹ����ٶ�
Vmax=1;
Vmin=-1;

%��Ⱥ
popmax=10;
popmin=-10;
nRep=50;    % Repository Size ��֧�����Ⱥ����
nGrid=7;      % Number of Grids per Dimension ÿ��Ŀ�꺯���⼯�����չ�����С����������
alpha=0.3;    % Inflation Rate ��֧���Ľ⼯����չ����

beta=2;       % Leader Selection Pressure   ��֧����ѡ������
gamma=2;      % Deletion Selection Pressure ��֧������̭����

mu=0.1;             % Mutation Rate
temp13=zeros(1,4);
temp35=zeros(1,4);
temp24=zeros(1,4);
temp46=zeros(1,4);
tempp13=zeros(1,4);
tempp35=zeros(1,4);
tempp24=zeros(1,4);
tempp46=zeros(1,4);
sum1=0;sum2=0;sum3=0;sum4=0;
sum=0;
%%%%1.����һ�������ṹ�壻
POP.X = zeros(DIM1,DIM2);
POP.V = zeros(DIM1,DIM2);
POP.XBest=zeros(DIM1,DIM2);
POP.FIT=zeros(2,1);
POP.Fit1=0;POP.Fit2=0;
POP.FitBest=zeros(2,1);
POP.b= zeros(DIM1,DIM9);
POP.tts= zeros(DIM1,DIM9);
POP.temp=zeros(1,6); 
POP.tempp=zeros(1,3);
POP.IsDominated=[];   % �Ƿ��֧��⣬֧���=1, ��֧���=0
POP.GridIndex=[];     % ��֧�������񻯲���ֵ-������ѭ����������Ŀ�꺯�������л��ڣ�
POP.GridSubIndex=[];  % ÿһ����֧������������ֵ����չȡֵ��Χ�ڣ�
%%%% 2.���� repmat�����ݱ����ṹ��������ά�ȣ�
pop = repmat(POP,1,sizepop);%%
Vmax=zeros(DIM1,DIM2);
Xup= zeros(DIM1,DIM2);
Xdown=zeros(DIM1,DIM2);
for ii=1:DIM1
    for jj=1:DIM2
        Xup(ii,jj)= bmax(ii);
        Xdown(ii,jj)=bmin(ii);
        Vmax(ii,jj)=bmax(ii)-bmin(ii);
    end
end


    
%% ������ʼ���Ӻ��ٶ�
for i=1:sizepop
    for ii=1:DIM1
        for jj=1:DIM2
            pop(i).X=rand(DIM1,DIM2)*(Xup(ii,jj)-Xdown(ii,jj)+Xdown(ii,jj));  %��ʼ��Ⱥ
            pop(i).V=rand(DIM1,DIM2)*Vmax(ii,jj)-Vmax(ii,jj)/2;  %��ʼ���ٶ�
            pop(i).XBest(ii,jj)=pop(i).X(ii,jj);%��������
            
        end
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Լ������
for j=1:sizepop
            %2.XIUFU2������������
            D=zeros(1,DIM1);
                for i2=1:DIM1
                    for n2=1:DIM2
                        D(i2)=D(i2)+pop(j).X(i2,n2);
                    end
                    if(D(i2)>demand(i2))%�������������󣬴Ӻ���ǰ����
                        
                        for j2=(DIM2):-1:1
                            D(i2)=D(i2)-pop(j).X(i2,j2);
                            if(D(i2)>demand(i2))
                                pop(j).X(i2,j2)=0;
                            else
                                pop(j).X(i2,j2)=demand(i2)-D(i2);
                                D(i2)=demand(i2);
                            end
                            if(D(i2)==demand(i2))
                                break;
                            end
                        end
                    end    
                        if(D(i2)<demand(i2))%�������������󣬴Ӻ���ǰ����
                            for j2=(DIM2):-1:1
                                if(pop(j).X(i2,j2)~=0)
                                    D(i2)=D(i2)+bmax(i2)-pop(j).X(i2,j2);
                                    if(D(i2)<=demand(i2))
                                        pop(j).X(i2,j2)=bmax(i2);
                                    else
                                        pop(j).X(i2,j2)=bmax(i2)-(D(i2)-demand(i2));
                                        D(i2)=demand(i2);
                                    end
                                end
                                if(D(i2)==demand(i2))
                                    break;
                                end
                            end
                        end
                    
                end



%%
%             1.transit
           %p.xת��Ϊp.b
           for r3=1:DIM4
               for i3=1:DIM6
                   im=I(r3,i3);
                   for n3=1:r3
                       pop(j).b(im,n3)=0;
                   end
                   for n3=r3+1:(r3+DIM2)
                       pop(j).b(im,n3+2)= pop(j).X(im,n3-r3);       
                   end
                 
               end
           end
           for a=1:DIM1
               for b=1:DIM9
                   pop(j).bb(a,b)=pop(j).b(a,b+3);
               end
           end
% 
% %%
% 
            %�����м��������Ƶ���
            
            
  for a=1:DIM3
    for b=1:DIM9+1
        E(a,b)=0;%�м��Ʒ�ۼ���
    end
end
k=0;

for a=3:4
    
    b=1;
    %3,2;4,2
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=200)
        pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
        k=b+1;
    else
        E(a,b+1)=pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1);
        
        if(E(a,b+1)>=0)
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
            pop(j).bb(a-2,b+1)=0;
            k=b+2;
            q1=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q1;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q1;
        else
            k=b+1;
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2);
            pop(j).bb(a-2,b+1)=0;pop(j).bb(a-2,b+2)=0;
            k=b+3;
            q2=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q2;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q2;
        end    
    end
        b=3;
        E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);%3,3;4,3
        if(E(a,b)>=0&&E(a,b)<=Emax(a+3))
            E(a,b)=E(a,b);
            pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1);
        else
            if(E(a,b)<0)
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+pop(j).bb(a-2,b);
                pop(j).bb(a-2,b)=0;pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                tem1=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)-tem1;
                if(pop(j).bb(a-2,b)>=-tem1)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+tem1;
                else
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+tem1;
                end
                E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                E(a,b+1)=E(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);%3,4;4,4
                if(E(a,b+1)>=0&&E(a,b+1)<=Emax(a+3))
                    E(a,b+1)=E(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                elseif(E(a,b+1)<0)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
                    pop(j).bb(a-2,b+1)=0;
                    tem2=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-tem2;
                    pop(j).bb(a-2,b+1)=300-pop(j).bb(a-2,b)-pop(j).bb(a-2,b-1)-pop(j).bb(a-2,b-2);
                end
            end
            if(E(a,b)>Emax(a+3))
                temp=E(a,b)-Emax(a+3);
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+temp;
                pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-temp;
                E(a,b)=Emax(a+3);
            end
        end
        if (pop(j).bb(a-2,4)<0)
            pop(j).bb(a-2,3)=pop(j).bb(a-2,3)-pop(j).bb(a-2,4);
            pop(j).bb(a-2,4)=0;
        end
        if(pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1)>demand(1,a))
            for n=4:-1:1
                if(pop(j).bb(a-2,n)~=0)
                    pop(j).bb(a-2,n)=pop(j).bb(a-2,n)-((pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1))-demand(1,a));
                end
            end
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for a=5:6
    
    b=2;
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=200)
        pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
    else
        if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<0)
            w1=pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w1;
            pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w1;
        end
    end
    
    b=4;
    E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
    if(E(a,b)>=0&&E(a,b)<=Emax(a+3))
        pop(j).bb(a,b)=pop(j).bb(a,b);
    else
        if(E(a,b)<0)
            w2=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            pop(j).bb(a,b)=pop(j).bb(a,b)+w2;
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w2;
            E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            if(E(a,b)>Emax(a+3))
                temp=E(a,b)-Emax(a+3);
                pop(j).bb(a,b)=pop(j).bb(a-2,b)-temp;
                pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)+temp;
                E(a,b)=Emax(a+3);
            end
            E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            if(E(a,b+1)>=0&&E(a,b+1)<=Emax(a+3))
                pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
            else
                if(E(a,b+1)<0)
                    w3=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w3;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w3;
                    E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    if(E(a,b+1)>Emax(a+3))
                        temp=E(a,b)-Emax(a+3);
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+1)=Emax(a+3);
                    end
                   
                end
            end
                        E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
            if(E(a,b+2)>=0&&E(a,b+2)<=Emax(a+3))
                pop(j).bb(a,b+2)=pop(j).bb(a,b+2);
            else
                if(E(a,b+2)<0)
                    w4=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w4;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)+w4;
                    E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    if(E(a,b+2)>Emax(a+3))
                        temp=E(a,b)-Emax(a+3);
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+2)=Emax(a+3);
                    end
                   
                end
            end
        end
        
    end
    
    if(pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3)>demand(1,a))
        for n=6:-1:3
            if(pop(j).bb(a,n)~=0)
                pop(j).bb(a,n)=pop(j).bb(a,n)-((pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3))-demand(1,a));
            end
        end
    end
end
           
               



%% 
% % %             %2.calmodel
       
                 pop(j).tts= zeros(DIM1,DIM9);    
                 for i=1:stage_task(1)
                     pop(j).tts(i,1)=0;          %����ʼ����ĵ�һ���豸�ĸ�����ĵ�һ��������ֵΪ��
                 end
                 total_stage_task=stage_task(1);
                 for is=2:DIM4
                     
                     for i=(total_stage_task+1):(total_stage_task+stage_task(is))
                         
                         for n=1:is
                             pop(j).tts(i,n)=0;
                         end
                     end
                     total_stage_task=total_stage_task+stage_task(is);
                 end                                  %�������Ǹ���ֵΪ��
     

                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
                          
            total_stage_task=0;
  
             pop(j).tts(1,1)=pop(j).bb(1,1)*change_task(1)+fix_task(1);
             pop(j).tts(2,1)=(pop(j).tts(1,1)+(pop(j).bb(2,1)*change_task(1)+fix_task(1)));  
            for i=(total_stage_task+1):(DIM1)
                 for n=1:DIM9-DIM4+3
                             immediate_t1=0;immediate_t2=0;immediate_t3=0;immediate_t4=0;
                             if(i-DIM6<=0)
                                 if(n==2) 
                                     if(i==1)
                                        %1,2
                                         immediate_t1=(pop(j).tts(i+1,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                                         
                                     elseif(i==2)
                                         %2,2
                                         immediate_t1=(pop(j).tts(i-1,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                                         %1,3
                                         immediate_t1=pop(j).tts(i,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                                          immediate_t2=pop(j).tts(i-1,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                                         pop(j).tts(i-1,n+1)=maxx(immediate_t1,immediate_t2);
                                        
                                     end

                                 end
                                
                             end
                             
                             if(i-DIM6>0)
                              %3,2;3,3;4,2;4,3
                                 if(n+1<=3)
                                     if(i==3)
                                     immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+1)=maxx(immediate_t1,immediate_t2);
                                     elseif(i==4)
                                     immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i-1,n+1)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+1)=maxx((maxx(immediate_t1,immediate_t2)),pop(j).tts(i-2,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                     end
                                 end
                                %     5,3;5,4;6,3;6,4
                                 if(n+2<=4)
                                     if(i==5)
                                     immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+2)=maxx(immediate_t1,immediate_t2);
                                     elseif(i==6)
                                     immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i-1,n+2)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+2)=maxx((maxx(immediate_t1,immediate_t2)),(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i))));
                                     end
                                 end
                                 
                         end
                         total_stage_task=total_stage_task+stage_task(is);
                 end   
            end
            
            
           pop(j).tts(2,3)=maxx(pop(j).tts(1,3)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)),pop(j).tts(2,2)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)));
           pop(j).tts(1,4)=maxx(pop(j).tts(2,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)),pop(j).tts(1,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)));
           pop(j).tts(2,4)=maxx(pop(j).tts(1,4)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)),pop(j).tts(2,3)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)));
           
           pop(j).tts(3,4)=maxx(pop(j).tts(1,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)),pop(j).tts(3,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)));
           pop(j).tts(4,4)=maxx(maxx(pop(j).tts(2,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)),pop(j).tts(3,4)+(pop(j).bb(4,4)*change_task(4)+fix_task(4))),pop(j).tts(4,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)));
           pop(j).tts(3,5)=maxx(pop(j).tts(1,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)),pop(j).tts(3,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)));
            pop(j).tts(4,5)=maxx(maxx(pop(j).tts(2,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)),pop(j).tts(3,5)+(pop(j).bb(4,5)*change_task(5)+fix_task(5))),pop(j).tts(4,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)));
            
            pop(j).tts(5,5)=maxx(pop(j).tts(3,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)),pop(j).tts(5,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)));
            pop(j).tts(6,5)=maxx(maxx(pop(j).tts(4,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)),pop(j).tts(5,5)+(pop(j).bb(6,5)*change_task(5)+fix_task(5))),pop(j).tts(6,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)));
            pop(j).tts(5,6)=maxx(pop(j).tts(3,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)),pop(j).tts(5,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)));
            pop(j).tts(6,6)=maxx(maxx(pop(j).tts(4,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)),pop(j).tts(5,6)+(pop(j).bb(6,6)*change_task(6)+fix_task(6))),pop(j).tts(6,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)));
            
            
          
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Լ����������
         

%             pop(j).Fit1=pop(j).tts(DIM1,DIM9);
%             
%            
%             for i=1:DIM1
%                 fff=pop(j).tts(i,DIM9);
%                 
%                 if(pop(j).Fit1>fff&&fff~=0)
%                     pop(j).Fit1=fff;
%                 end
%                 
%             end
            
pop(j).Fit1=pop(j).tts(DIM1,DIM9)-pop(j).tts(2,1);
fff=pop(j).tts(DIM1-1,DIM9)-pop(j).tts(1,1);

if(pop(j).Fit1>fff&&fff~=0)
    pop(j).Fit1=fff;
end
 temp13(1)=pop(j).bb(1,1)-pop(j).bb(3,2);
 temp35(1)=pop(j).bb(3,2)-pop(j).bb(5,3);
 for i=1:3
     if(temp13(i)>=0)
         temp13(i+1)=temp13(i)+pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     else
         temp13(i+1)=pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     end
     if(temp35(i)>=0)
         temp35(i+1)=temp35(i)+pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     else
         temp35(i+1)=pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     end
 end
 temp24(1)=pop(j).bb(2,1)-pop(j).bb(4,2);
 temp46(1)=pop(j).bb(4,2)-pop(j).bb(6,3);
 for i=1:3
     if(temp24(i)>=0)
         temp24(i+1)=temp24(i)+pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     else
         temp24(i+1)=pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     end
     if(temp46(i)>=0)
         temp46(i+1)=temp46(i)+pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     else
         temp46(i+1)=pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     end
 end

                
tempp13(1)=(pop(j).tts(3,2)-pop(j).tts(1,1)-fix(pop(j).bb(3,2)*change_task(2)-fix_task(2)));
tempp35(1)=(pop(j).tts(5,3)-pop(j).tts(3,2)-fix(pop(j).bb(5,3)*change_task(3)-fix_task(3)));
for i=1:3
     if(tempp13(i)>=0)
         tempp13(i+1)=(pop(j).tts(3,i+2)-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1))-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp13(i+1)=(pop(j).tts(3,i+2))-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1)-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp35(i)>=0)
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 tempp24(1)=(pop(j).tts(4,2)-maxx(pop(j).tts(2,1),pop(j).tts(3,2))-fix(pop(j).bb(4,2)*change_task(2)-fix_task(2)));
 tempp46(1)=(pop(j).tts(6,3)-maxx(pop(j).tts(4,2),pop(j).tts(5,3))-fix(pop(j).bb(6,3)*change_task(3)-fix_task(3)));
 for i=1:3
     if(tempp24(i)>=0)
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp46(i)>=0)
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 for i=1:4
     sum1=sum1+2*temp13(i)*tempp13(i);
     sum2=sum2+2*temp35(i)*tempp35(i);
     sum3=sum3+2*temp24(i)*tempp24(i);
     sum4=sum4+2*temp46(i)*tempp46(i);
 end
 sum=sum1+sum2+sum3+sum4;
 pop(j).Fit2=sum;

 
            pop(j).FIT =[pop(j).Fit1,pop(j).Fit2]';
			 pop(j).FitBest = pop(j).FIT;
end

    pop=DetermineDomination(pop);  % ȷ����Ⱥ֮���Ƿ����֧���
    
    rep=pop(~[pop.IsDominated]);   % Ȼ���ȡ��֧���
    
    Grid=CreateGrid(rep,nGrid,alpha);  % ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
    
    for i=1:numel(rep)
        rep(i)=FindGridIndex(rep(i),Grid);  % ������չ��֧����GridIndex
    end
%ʹ���з�֧��ⶼ��ǰ������
    for i=1:numel(rep)
        for j=1:numel(pop)
            if(rep(i).Fit1>pop(j).Fit1&&rep(i).Fit2>pop(j).Fit2)
                temp=rep(i);
                rep(i)=pop(j);
                pop(j)=temp;
            end
        end
    end
  
% 
% %% ����Ѱ��

for i=1:maxgen
    
    for j=1:sizepop

        for ii=1:DIM1
            for jj=1:DIM2
                [leader,sm]=SelectLeader(rep,beta);
                %�ٶȸ���
                pop(j).V(ii,jj)  = 0.5*pop(j).V(ii,jj)  + c1*rand(1)*(pop(j).XBest(ii,jj)+(-pop(j).X(ii,jj))) + c2*rand(1)*(leader.X(ii,jj)+(-pop(j).X(ii,jj)));
                if (pop(j).V(ii,jj)>Vmax(ii,jj))  %����ٶ������Сֵ
                    pop(j).V(ii,jj)=Vmax(ii,jj);
                end
                if(pop(j).V(ii,jj)<-Vmax(ii,jj))
                    pop(j).V(ii,jj)=-Vmax(ii,jj);
                end
                
                %��Ⱥ����
                pop(j).X(ii,jj)=pop(j).X(ii,jj)+0.5*pop(j).V(ii,jj);
                if (pop(j).X(ii,jj)>Xup(ii,jj))%���λ�������Сֵ
                    pop(j).X(ii,jj)=Xup(ii,jj);
                end
                if(pop(j).X(ii,jj)<Xdown(ii,jj))
                    pop(j).X(ii,jj)=(Xup(ii,jj)-Xdown(ii,jj))*rand(1)+Xdown(ii,jj);
                end
                

                        %%
            %2.XIUFU2������������
            D=zeros(1,DIM1);
                for i2=1:DIM1
                    for n2=1:DIM2
                        D(i2)=D(i2)+pop(j).X(i2,n2);
                    end
                    if(D(i2)>demand(i2))%�������������󣬴Ӻ���ǰ����
                        
                        for j2=(DIM2):-1:1
                            D(i2)=D(i2)-pop(j).X(i2,j2);
                            if(D(i2)>demand(i2))
                                pop(j).X(i2,j2)=0;
                            else
                                pop(j).X(i2,j2)=demand(i2)-D(i2);
                                D(i2)=demand(i2);
                            end
                            if(D(i2)==demand(i2))
                                break;
                            end
                        end
                    end    
                        if(D(i2)<demand(i2))%�������������󣬴Ӻ���ǰ����
                            for j2=(DIM2):-1:1
                                if(pop(j).X(i2,j2)~=0)
                                    D(i2)=D(i2)+bmax(i2)-pop(j).X(i2,j2);
                                    if(D(i2)<=demand(i2))
                                        pop(j).X(i2,j2)=bmax(i2);
                                    else
                                        pop(j).X(i2,j2)=bmax(i2)-(D(i2)-demand(i2));
                                        D(i2)=demand(i2);
                                    end
                                end
                                if(D(i2)==demand(i2))
                                    break;
                                end
                            end
                        end
                    
                end



%%
%             1.transit
           %p.xת��Ϊp.b
           for r3=1:DIM4
               for i3=1:DIM6
                   im=I(r3,i3);
                   for n3=1:r3
                       pop(j).b(im,n3)=0;
                   end
                   for n3=r3+1:(r3+DIM2)
                       pop(j).b(im,n3+2)= pop(j).X(im,n3-r3);       
                   end
                 
               end
           end
           for a=1:DIM1
               for b=1:DIM9
                   pop(j).bb(a,b)=pop(j).b(a,b+3);
               end
           end


%

            %�����м��������Ƶ���
            
for a=3:4
    
    b=1;
    %3,2;4,2
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=200)
        pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
        k=b+1;
    else
        E(a,b+1)=pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1);
        
        if(E(a,b+1)>=0)
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
            pop(j).bb(a-2,b+1)=0;
            k=b+2;
            q1=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q1;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q1;
        else
            k=b+1;
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2);
            pop(j).bb(a-2,b+1)=0;pop(j).bb(a-2,b+2)=0;
            k=b+3;
            q2=(pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1)+pop(j).bb(a-2,b+2)-pop(j).bb(a,b+1));
            pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-q2;
            pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+q2;
        end    
    end
        b=3;
        E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);%3,3;4,3
        if(E(a,b)>=0&&E(a,b)<=Emax(a+3))
            E(a,b)=E(a,b);
            pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1);
        else
            if(E(a,b)<0)
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+pop(j).bb(a-2,b);
                pop(j).bb(a-2,b)=0;pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                tem1=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)-tem1;
                if(pop(j).bb(a-2,b)>=-tem1)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+tem1;
                else
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1)+tem1;
                end
                E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
                E(a,b+1)=E(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);%3,4;4,4
                if(E(a,b+1)>=0&&E(a,b+1)<=Emax(a+3))
                    E(a,b+1)=E(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b);
                    pop(j).bb(a-2,b+1)=pop(j).bb(a-2,b+1);
                elseif(E(a,b+1)<0)
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)+pop(j).bb(a-2,b+1);
                    pop(j).bb(a-2,b+1)=0;
                    tem2=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-tem2;
                    pop(j).bb(a-2,b+1)=300-pop(j).bb(a-2,b)-pop(j).bb(a-2,b-1)-pop(j).bb(a-2,b-2);
                end
            end
            if(E(a,b)>Emax(a+3))
                temp=E(a,b)-Emax(a+3);
                pop(j).bb(a-2,b-1)=pop(j).bb(a-2,b-1)+temp;
                pop(j).bb(a-2,b)=pop(j).bb(a-2,b)-temp;
                E(a,b)=Emax(a+3);
            end
        end
        if (pop(j).bb(a-2,4)<0)
            pop(j).bb(a-2,3)=pop(j).bb(a-2,3)-pop(j).bb(a-2,4);
            pop(j).bb(a-2,4)=0;
        end
        if(pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1)>demand(1,a))
            for n=4:-1:1
                if(pop(j).bb(a-2,n)~=0)
                    pop(j).bb(a-2,n)=pop(j).bb(a-2,n)-((pop(j).bb(a-2,4)+pop(j).bb(a-2,3)+pop(j).bb(a-2,2)+pop(j).bb(a-2,1))-demand(1,a));
                end
            end
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for a=5:6
    
    b=2;
    if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)>=0&&pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<=200)
        pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
    else
        if(pop(j).bb(a-2,b)-pop(j).bb(a,b+1)<0)
            w1=pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w1;
            pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w1;
        end
    end
    
    b=4;
    E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
    if(E(a,b)>=0&&E(a,b)<=Emax(a+3))
        pop(j).bb(a,b)=pop(j).bb(a,b);
    else
        if(E(a,b)<0)
            w2=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            pop(j).bb(a,b)=pop(j).bb(a,b)+w2;
            pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w2;
            E(a,b)=pop(j).bb(a-2,b-2)-pop(j).bb(a,b-1)+pop(j).bb(a-2,b-1)-pop(j).bb(a,b);
            if(E(a,b)>Emax(a+3))
                temp=E(a,b)-Emax(a+3);
                pop(j).bb(a,b)=pop(j).bb(a-2,b)-temp;
                pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)+temp;
                E(a,b)=Emax(a+3);
            end
            E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
            if(E(a,b+1)>=0&&E(a,b+1)<=Emax(a+3))
                pop(j).bb(a,b+1)=pop(j).bb(a,b+1);
            else
                if(E(a,b+1)<0)
                    w3=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)+w3;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)-w3;
                    E(a,b+1)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1);
                    if(E(a,b+1)>Emax(a+3))
                        temp=E(a,b)-Emax(a+3);
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+1)=Emax(a+3);
                    end
                   
                end
            end
            E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
            if(E(a,b+2)>=0&&E(a,b+2)<=Emax(a+3))
                pop(j).bb(a,b+2)=pop(j).bb(a,b+2);
            else
                if(E(a,b+2)<0)
                    w4=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    pop(j).bb(a,b+1)=pop(j).bb(a,b+1)-w4;
                    pop(j).bb(a,b+2)=pop(j).bb(a,b+2)+w4;
                    E(a,b+2)=pop(j).bb(a-2,b-1)-pop(j).bb(a,b)+pop(j).bb(a-2,b)-pop(j).bb(a,b+1)+pop(j).bb(a-2,b+1)-pop(j).bb(a,b+2);
                    if(E(a,b+2)>Emax(a+3))
                        temp=E(a,b)-Emax(a+3);
                        pop(j).bb(a,b+1)=pop(j).bb(a-2,b+1)-temp;
                        pop(j).bb(a,b+2)=pop(j).bb(a-2,b+2)+temp;
                        E(a,b+2)=Emax(a+3);
                    end
                   
                end
            end
        end
        
    end
    
    if(pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3)>demand(1,a))
        for n=6:-1:3
            if(pop(j).bb(a,n)~=0)
                pop(j).bb(a,n)=pop(j).bb(a,n)-((pop(j).bb(a,6)+pop(j).bb(a,5)+pop(j).bb(a,4)+pop(j).bb(a,3))-demand(1,a));
            end
        end
    end
end
           
               


% 
% %% 
% % % % %             %2.calmodel
            
                 pop(j).tts= zeros(DIM1,DIM9);    
                 for i=1:stage_task(1)
                     pop(j).tts(i,1)=0;          %����ʼ����ĵ�һ���豸�ĸ�����ĵ�һ��������ֵΪ��
                 end
                 total_stage_task=stage_task(1);
                 for is=2:DIM4
                     
                     for i=(total_stage_task+1):(total_stage_task+stage_task(is))
                         
                         for n=1:is
                             pop(j).tts(i,n)=0;
                         end
                     end
                     total_stage_task=total_stage_task+stage_task(is);
                 end                                  %�������Ǹ���ֵΪ��
     

                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
                          
            total_stage_task=0;
  
             pop(j).tts(1,1)=pop(j).bb(1,1)*change_task(1)+fix_task(1);
             pop(j).tts(2,1)=(pop(j).tts(1,1)+(pop(j).bb(2,1)*change_task(1)+fix_task(1)));  
            for i=(total_stage_task+1):(DIM1)
                 for n=1:DIM9-DIM4+3
                             immediate_t1=0;immediate_t2=0;immediate_t3=0;immediate_t4=0;
                             if(i-DIM6<=0)
                                 if(n==2) 
                                     if(i==1)
                                        %1,2
                                         immediate_t1=(pop(j).tts(i+1,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                                         
                                     elseif(i==2)
                                         %2,2
                                         immediate_t1=(pop(j).tts(i-1,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         immediate_t2=(pop(j).tts(i,n-1)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                         pop(j).tts(i,n)=maxx(immediate_t1,immediate_t2);
                                         %1,3
                                         immediate_t1=pop(j).tts(i,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                                          immediate_t2=pop(j).tts(i-1,n)+(pop(j).bb(i-1,n+1)*change_task(i)+fix_task(i));
                                         pop(j).tts(i-1,n+1)=maxx(immediate_t1,immediate_t2);
                                        
                                     end

                                 end
                                
                             end
                             if(i-DIM6>0)
                              %3,2;3,3;4,2;4,3
                                 if(n+1<=3)
                                     if(i==3)
                                     immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+1)=maxx(immediate_t1,immediate_t2);
                                     elseif(i==4)
                                     immediate_t1=(pop(j).tts(i-2,n)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i-1,n+1)+(pop(j).bb(i,n+1)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+1)=maxx((maxx(immediate_t1,immediate_t2)),pop(j).tts(i-2,n)+(pop(j).bb(i,n)*change_task(i)+fix_task(i)));
                                     end
                                 end
                                %     5,3;5,4;6,3;6,4
                                 if(n+2<=4)
                                     if(i==5)
                                     immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+2)=maxx(immediate_t1,immediate_t2);
                                     elseif(i==6)
                                     immediate_t1=(pop(j).tts(i-2,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     immediate_t2=(pop(j).tts(i-1,n+2)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i)));
                                     pop(j).tts(i,n+2)=maxx((maxx(immediate_t1,immediate_t2)),(pop(j).tts(i,n+1)+(pop(j).bb(i,n+2)*change_task(i)+fix_task(i))));
                                     end
                                 end
                                 
                         end
                         total_stage_task=total_stage_task+stage_task(is);
                 end   
            end
            
            
           pop(j).tts(2,3)=maxx(pop(j).tts(1,3)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)),pop(j).tts(2,2)+(pop(j).bb(2,3)*change_task(3)+fix_task(3)));
           pop(j).tts(1,4)=maxx(pop(j).tts(2,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)),pop(j).tts(1,3)+(pop(j).bb(1,4)*change_task(4)+fix_task(4)));
           pop(j).tts(2,4)=maxx(pop(j).tts(1,4)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)),pop(j).tts(2,3)+(pop(j).bb(2,4)*change_task(4)+fix_task(4)));
           
           pop(j).tts(3,4)=maxx(pop(j).tts(1,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)),pop(j).tts(3,3)+(pop(j).bb(3,4)*change_task(4)+fix_task(4)));
           pop(j).tts(4,4)=maxx(maxx(pop(j).tts(2,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)),pop(j).tts(3,4)+(pop(j).bb(4,4)*change_task(4)+fix_task(4))),pop(j).tts(4,3)+(pop(j).bb(4,4)*change_task(4)+fix_task(4)));
           pop(j).tts(3,5)=maxx(pop(j).tts(1,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)),pop(j).tts(3,4)+(pop(j).bb(3,5)*change_task(5)+fix_task(5)));
            pop(j).tts(4,5)=maxx(maxx(pop(j).tts(2,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)),pop(j).tts(3,5)+(pop(j).bb(4,5)*change_task(5)+fix_task(5))),pop(j).tts(4,4)+(pop(j).bb(4,5)*change_task(5)+fix_task(5)));
            
            pop(j).tts(5,5)=maxx(pop(j).tts(3,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)),pop(j).tts(5,4)+(pop(j).bb(5,5)*change_task(5)+fix_task(5)));
            pop(j).tts(6,5)=maxx(maxx(pop(j).tts(4,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)),pop(j).tts(5,5)+(pop(j).bb(6,5)*change_task(5)+fix_task(5))),pop(j).tts(6,4)+(pop(j).bb(6,5)*change_task(5)+fix_task(5)));
            pop(j).tts(5,6)=maxx(pop(j).tts(3,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)),pop(j).tts(5,5)+(pop(j).bb(5,6)*change_task(6)+fix_task(6)));
            pop(j).tts(6,6)=maxx(maxx(pop(j).tts(4,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)),pop(j).tts(5,6)+(pop(j).bb(6,6)*change_task(6)+fix_task(6))),pop(j).tts(6,5)+(pop(j).bb(6,6)*change_task(6)+fix_task(6)));
            
          
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
%             pop(j).Fit1=pop(j).tts(DIM1,DIM9);
%             
%            
%             for i=1:DIM1
%                 fff=pop(j).tts(i,DIM9);
%                 
%                 if(pop(j).Fit1>fff&&fff~=0)
%                     pop(j).Fit1=fff;
%                 end
%                 
%             end
pop(j).Fit1=pop(j).tts(DIM1,DIM9)-pop(j).tts(2,1);
fff=pop(j).tts(DIM1-1,DIM9)-pop(j).tts(1,1);
                if(pop(j).Fit1>fff&&fff~=0)
                    pop(j).Fit1=fff;
                end

 temp13(1)=pop(j).bb(1,1)-pop(j).bb(3,2);
 temp35(1)=pop(j).bb(3,2)-pop(j).bb(5,3);
 for i=1:3
     if(temp13(i)>=0)
         temp13(i+1)=temp13(i)+pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     else
         temp13(i+1)=pop(j).bb(1,(i+1))-pop(j).bb(3,(i+2));
     end
     if(temp35(i)>=0)
         temp35(i+1)=temp35(i)+pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     else
         temp35(i+1)=pop(j).bb(3,(i+2))-pop(j).bb(5,(i+3));
     end
 end
 temp24(1)=pop(j).bb(2,1)-pop(j).bb(4,2);
 temp46(1)=pop(j).bb(4,2)-pop(j).bb(6,3);
 for i=1:3
     if(temp24(i)>=0)
         temp24(i+1)=temp24(i)+pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     else
         temp24(i+1)=pop(j).bb(2,(i+1))-pop(j).bb(4,(i+2));
     end
     if(temp46(i)>=0)
         temp46(i+1)=temp46(i)+pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     else
         temp46(i+1)=pop(j).bb(4,(i+2))-pop(j).bb(6,(i+3));
     end
 end

                
tempp13(1)=(pop(j).tts(3,2)-pop(j).tts(1,1)-fix(pop(j).bb(3,2)*change_task(2)-fix_task(2)));
tempp35(1)=(pop(j).tts(5,3)-pop(j).tts(3,2)-fix(pop(j).bb(5,3)*change_task(3)-fix_task(3)));
for i=1:3
     if(tempp13(i)>=0)
         tempp13(i+1)=(pop(j).tts(3,i+2)-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1))-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp13(i+1)=(pop(j).tts(3,i+2))-maxx(pop(j).tts(3,i+1),pop(j).tts(1,i+1)-fix(pop(j).bb(3,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp35(i)>=0)
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp35(i+1)=(pop(j).tts(5,i+3)-maxx(pop(j).tts(5,i+2),pop(j).tts(3,i+2))-fix(pop(j).bb(5,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 tempp24(1)=(pop(j).tts(4,2)-maxx(pop(j).tts(2,1),pop(j).tts(3,2))-fix(pop(j).bb(4,2)*change_task(2)-fix_task(2)));
 tempp46(1)=(pop(j).tts(6,3)-maxx(pop(j).tts(4,2),pop(j).tts(5,3))-fix(pop(j).bb(6,3)*change_task(3)-fix_task(3)));
 for i=1:3
     if(tempp24(i)>=0)
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     else
         tempp24(i+1)=(pop(j).tts(4,i+2)-maxx(maxx(pop(j).tts(4,i+1),pop(j).tts(2,i+1)),pop(j).tts(3,i+2))-fix(pop(j).bb(4,i+2)*change_task(i+2)-fix_task(i+2)));
     end
     if(tempp46(i)>=0)
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     else
         tempp46(i+1)=(pop(j).tts(6,i+3)-maxx(maxx(pop(j).tts(6,i+2),pop(j).tts(4,i+2)),pop(j).tts(5,i+3))-fix(pop(j).bb(6,i+3)*change_task(i+3)-fix_task(i+3)));
     end
 end
 for i=1:4
     sum1=sum1+2*temp13(i)*tempp13(i);
     sum2=sum2+2*temp35(i)*tempp35(i);
     sum3=sum3+2*temp24(i)*tempp24(i);
     sum4=sum4+2*temp46(i)*tempp46(i);
 end

 sum=sum1+sum2+sum3+sum4;
 pop(j).Fit2=sum;          

            pop(j).FIT =[pop(j).Fit1,pop(j).Fit2]';
			 pop(j).FitBest = pop(j).FIT;
                pop(j).FIT =[pop(j).Fit1,pop(j).Fit2]';
                if Dominates(pop(j).X(ii,jj),pop(j).XBest(ii,jj))%����pop(i).XBest
                    pop(j).XBest(ii,jj)=pop(j).X(ii,jj);
                    pop(j).FitBest=pop(j).FIT;
                    
                elseif Dominates(pop(j).XBest(ii,jj),pop(j).X(ii,jj))
                    % Do Nothing
                    
                else
                    if rand<0.5
                        pop(j).XBest(ii,jj)=pop(j).X(ii,jj);
                        pop(j).FitBest=pop(j).FIT;
                    end
                end
                
            end
        end
    end
 
         % Add Non-Dominated Particles to REPOSITORY  ���ӷ�֧���
    rep=[rep pop(~[pop.IsDominated])]; 
    %ʹ���з�֧��ⶼ��ǰ������
    for i=1:numel(rep)
        for j=1:numel(pop)
            if(rep(i).Fit1>pop(j).Fit1&&rep(i).Fit2>pop(j).Fit2)
                temp=rep(i);
                rep(i)=pop(j);
                pop(j)=temp;
            end
        end
    end

    % Determine Domination of New Resository Members  ��֧����Ƿ���֧���
    rep=DetermineDomination(rep);

    % Keep only Non-Dminated Memebrs in the Repository % ɾ��֧���
    
    rep=rep(~[rep.IsDominated]);



    % Update Grid 
    Grid=CreateGrid(rep,nGrid,alpha);

    % Update Grid Indices ��չ��֧������Ӧ�Ⱥ���ȡֵ��Χ
    for i=1:numel(rep)
        rep(i)=FindGridIndex(rep(i),Grid);
    end

    % Check if Repository is Full ��֧����Ƿ�ﵽ���ķ�֧������Ⱥ��
    if numel(rep)>nRep
        % ����������Ⱥɾ��
        Extra=numel(rep)-nRep;
        for e=1:Extra
            rep=DeleteOneRepMemebr(rep,gamma);
        end
        
    end


  % Plot Costs
    figure(1);
    PlotCosts(pop,rep);
    pause(0.1);  
% ���
% 
end

disp '*************best particle number****************'
[leader,sm]=SelectLeader(rep,beta);
numel(rep)
rep.FitBest
rep.X
rep.bb
rep.tts
% plot(yy,'linewidth',2);
% title(['��Ӧ������  ' '��ֹ������' num2str(maxgen)]);
% xlabel('��������');ylabel('��Ӧ��');
% grid on