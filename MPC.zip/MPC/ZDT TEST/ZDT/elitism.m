function chromo = elitism(chromo_co)
    
    global nPop f_num x_num
    NP=nPop;
    chromo_co_sort = sortrows(chromo_co, x_num+f_num+1); % �� pareto_rank ����
    chromo = [];
    pareto_rank = 1;
    
    while 1 == 1
        
        % ȡ�� pareto_rank ����
        temp = chromo_co_sort(chromo_co_sort(:,x_num+f_num+1)==pareto_rank,:);
        if (size(temp, 1) + size(chromo, 1)) < NP % û������һֱ��
            chromo = [chromo; temp];
        else
            remain = NP - size(chromo, 1);
            temp = sortrows(temp, -(x_num+f_num+2)); % ��ӵ��������
            temp = temp(1:remain,:);
            chromo = [chromo; temp];
            break; % �����˾��չ�
        end
        
        pareto_rank = pareto_rank + 1;
        
    end
    
end
