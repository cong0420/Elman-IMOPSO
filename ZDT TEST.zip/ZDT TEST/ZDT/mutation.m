function chromo = mutation(chromo_cro)

global nPop x_num f_num x_min x_max pm yita2
NP=size(chromo_cro,1);
chromo = chromo_cro(:,1:x_num);  % ������ chromo_cro �����Ƕ����ˣ�������ֻ�õ� x_num ��

for i = 1:NP
    if rand < pm
        m=randperm(3,1);
        if(m==1)
            m1=randperm(10,2);
            temp=chromo(i,m1(1));
            chromo(i,m1(1))=chromo(i,m1(2));
            chromo(i,m1(2))=temp;
        elseif(m==2)
            m2=randperm(10,2);
            temp=chromo(i,10+m2(1));
            chromo(i,10+m2(1))=chromo(i,10+m2(2));
            chromo(i,10+m2(2))=temp;
        else
            m3=randperm(10,2);
            temp=chromo(i,20+m3(1));
            chromo(i,20+m3(1))=chromo(i,20+m3(2));
            chromo(i,20+m3(2))=temp;
        end
      
    end
    
%             for j = 1:x_num
%                 u = rand;
%                 if u < 0.5
%                     delta = (2 * u)^(1 / (yita2+1)) - 1;
%                 else
%                     delta = 1 - (2 * (1 - u))^(1 / (yita2+1));
%                 end
%                 chromo(i,j) = chromo(i,j) + delta;
%             end
    

       
   
        
        % ���峬���˾��޸���  
        for j=1:x_num
            if(chromo(i,j)>1)
                chromo(i,j)=1;
            elseif(chromo(i,j)< 0)
                chromo(i,j)=0;
            end
        end
%     chromo(i,1:x_num) = min(chromo(i,1:x_num), x_max);
%     chromo(i,1:x_num) = max(chromo(i,1:x_num), x_min);
    chromo(i,x_num+1:x_num+f_num) = object_fun(chromo(i,1:x_num)); % ˳������¸�Ŀ�꺯��ֵ��
    
end