function chromo = mutation(chromo_cro)

global nPop x_num f_num x_min x_max pm yita2
NP=size(chromo_cro,1);
chromo = chromo_cro(:,1:x_num);  % ������ chromo_cro �����Ƕ����ˣ�������ֻ�õ� x_num ��
sum=0;te=[];tte=[];
for i = 1:NP
    if rand < pm

%        m=randperm(3,1);
%         if(m==1)
%             m11=randperm(4,1);m12=randperm(4,1);
%             while(chromo(i,m11)==0||chromo(i,m12+4)==0)
%               m11=randperm(4,1);  
%               m12=randperm(4,1);
%             end
%             temp1=chromo(i,m11);
%             chromo(i,m11)=chromo(i,m12+4);
%             chromo(i,m12+4)=temp1;
% 
%            
%         elseif(m==2)
%             m21=randperm(4,1);m22=randperm(4,1);
%              while(chromo(i,m21+4*2)==0||chromo(i,m22+4+4*2)==0)
%               m21=randperm(4,1);  
%               m22=randperm(4,1);
%             end
%             temp1=chromo(i,m21+4*2);
%             chromo(i,m21+4*2)=chromo(i,m22+4*3);
%             chromo(i,m22+4*3)=temp1;
% 
%            
%         else
%             m31=randperm(4,1);m32=randperm(4,1);
%             while(chromo(i,m31+4*4)==0||chromo(i,m32+4+4*4)==0)
%               m31=randperm(4,1);  
%               m32=randperm(4,1);
%             end
%             temp1=chromo(i,m31+4*4);
%             chromo(i,m31+4*4)=chromo(i,m32+4*5);
%             chromo(i,m32+4*5)=temp1;
%         end
for j = 1:x_num
    u = rand;
    if u < 0.5
        delta = (2 * u)^(1 / (yita2+1)) - 1;
    else
        delta = 1 - (2 * (1 - u))^(1 / (yita2+1));
    end
    if chromo(i,j)~=0
    chromo(i,j) = chromo(i,j) + delta;
    end
end
            
        end
       
        for j=1:x_num
            if(chromo(i,j)> x_max(j))
                chromo(i,j)=x_max(j);
            elseif(chromo(i,j)< x_min(j))
                chromo(i,j)=x_min(j);
            end
        end
    end
    
    % ���峬���˾��޸���
   
    
    
end