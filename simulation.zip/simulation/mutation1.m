function chromo = mutation(chromo_cro)

global nPop x_num f_num x_min x_max pm yita2
NP=size(chromo_cro,1);
chromo = chromo_cro(:,1:x_num);  % ������ chromo_cro �����Ƕ����ˣ�������ֻ�õ� x_num ��
sum=0;te=[];tte=[];
for i = 1:NP
    if rand < pm
        %             m=randperm(3,1);
        %             if(m==1)
        %             m1=randperm(24,2);
        %             temp=chromo(i,m1(1));
        %             chromo(i,m1(1))=chromo(i,m1(2));
        %             chromo(i,m1(2))=temp;
        %             elseif(m==2)
        %             m2=randperm(24,2);
        %             temp=chromo(i,24+m2(1));
        %             chromo(i,24+m2(1))=chromo(i,24+m2(2));
        %             chromo(i,24+m2(2))=temp;
        %             else
        %             m3=randperm(24,2);
        %             temp=chromo(i,48+m3(1));
        %             chromo(i,48+m3(1))=chromo(i,48+m3(2));
        %             chromo(i,48+m3(2))=temp;
        %             end
        m=randperm(3,1);
        if(m==1)
            m11=randperm(10,1);m12=randperm(3,1);
            temp1=chromo(i,m11);
            chromo(i,m11)=chromo(i,m11+10*m12);
            chromo(i,m11+10*m12)=temp1;

           
        elseif(m==2)
            m21=randperm(10,1);m22=randperm(3,1);
            temp1=chromo(i,m21+4*10);
            chromo(i,m21+4*10)=chromo(i,m21+4*10+m22*10);
            chromo(i,m21+4*10+m22*10)=temp1;

           
        else
            m31=randperm(10,1);m32=randperm(3,1);
            temp1=chromo(i,m31+8*10);
            chromo(i,m31+8*10)=chromo(i,m31+8*10+m32*10);
            chromo(i,m31+8*10+m32*10)=temp1;
        end
         for j = 1:x_num
                u = rand;
                if u < 0.5
                    delta = (2 * u)^(1 / (yita2+1)) - 1;
                else
                    delta = 1 - (2 * (1 - u))^(1 / (yita2+1));
                end
                chromo(i,j) = chromo(i,j) + delta;
        end 
    end
    
    % ���峬���˾��޸���
    for j=1:x_num
        if(chromo(i,j)> x_max(j))
            chromo(i,j)=x_max(j);
        elseif(chromo(i,j)< x_min(j))
            chromo(i,j)=x_min(j);
        end
    end
    
    
end